i-JANICKI v7 — surowy terminal + funkcje z nowszych wersji

Pliki:
- index.html
- styles.css
- script.js

Co jest w tej wersji:
- układ bliższy pierwszej wersji, ale bardziej surowy i terminalowy
- tylko wybrane kolory w tekście (zielony / niebieski / bursztynowy / czerwony)
- lepsza obsługa kółka myszy (akumulacja + cooldown)
- komendy po polsku i po angielsku
- opisy projektów po wpisaniu nazwy domeny
- formularz kontaktowy i formularz oddzwonienia
- kopiowanie telefonu i e-maila z potwierdzeniem w terminalu
- sesja zapamiętywana na 5 minut z pytaniem o wznowienie
- light/dark mode
- poprawki mobilne

Formularz:
- wysyłka przez FormSubmit na: igor.janicki27@gmail.com
- przy pierwszym użyciu może przyjść mail aktywacyjny

Gdzie edytować:
- teksty i komendy: script.js
- wygląd: styles.css
- adres odbiorczy formularza: script.js -> CONTACT_EMAIL
