const CONTACT_EMAIL = 'igor.janicki27@gmail.com';
const CONTACT_PHONE = '57 57 57 817';
const STORAGE_KEY = 'ijanicki_terminal_state_v7';
const RESUME_TTL_MS = 5 * 60 * 1000;
const MIN_SUBMIT_INTERVAL_MS = 12000;

const ui = {
  output: document.getElementById('output'),
  stepCounter: document.getElementById('stepCounter'),
  metaLabel: document.getElementById('metaLabel'),
  prevBtn: document.getElementById('prevBtn'),
  nextBtn: document.getElementById('nextBtn'),
  commandInput: document.getElementById('commandInput'),
  commandLegend: document.getElementById('commandLegend'),
  langToggle: document.getElementById('langToggle'),
  themeToggle: document.getElementById('themeToggle'),
  skipToContact: document.getElementById('skipToContact'),
  floatingContact: document.getElementById('floatingContact'),
  callbackShortcut: document.getElementById('callbackShortcut'),
  bootOverlay: document.getElementById('bootOverlay'),
  bootText: document.getElementById('bootText'),
  contactTemplate: document.getElementById('contactTemplate')
};

const text = {
  pl: {
    title: 'i-JANICKI — Strony, aplikacje i opieka IT',
    description: 'i-JANICKI tworzy strony internetowe, aplikacje Python i Swift oraz wspiera małe biznesy w opiece informatycznej.',
    meta: 'sesja aktywna',
    next: 'dalej',
    prev: 'wstecz',
    contact: 'kontakt',
    callback: 'umów rozmowę',
    boot: [
      'boot :: i-JANICKI',
      'loading modules...',
      'web / python / swift / it-care',
      'status :: ready'
    ],
    commandsLabel: ['pomoc','dalej','wstecz','o mnie','usługi','projekty','kontakt','cennik','jak pracuję','strzelca.pl','get-dog.com','sredzka-korona.pl','formularz','oddzwon','jasny','ciemny','english','telefon','email'],
    steps: [
      {
        command: './start',
        lines: [
          line('Witaj. Nazywam się <span class="c-blue">Igor Janicki</span>.', 'line is-success'),
          block([
            'Tworzę <span class="c-green">strony internetowe</span>, <span class="c-green">aplikacje Python</span> i <span class="c-green">Swift</span>, a także zapewniam <span class="c-amber">opiekę informatyczną</span> dla małych biznesów.',
            'Ta strona działa jak <span class="c-blue">surowy terminal</span> — prosto, czytelnie i bez zbędnych ozdobników.',
            'Możesz przechodzić dalej <span class="c-amber">przyciskiem</span>, <span class="c-amber">Enterem</span>, <span class="c-amber">komendą</span> albo <span class="c-amber">kółkiem myszy</span>.'
          ]),
          muted('Wpisz `pomoc`, aby zobaczyć komendy.')
        ]
      },
      {
        command: 'cat o_mnie.txt',
        lines: [
          line('<span class="c-blue">[ o mnie ]</span>'),
          block([
            'Projektuję rzeczy, które mają <span class="c-green">dobrze wyglądać</span>, <span class="c-green">działać stabilnie</span> i nie utrudniać pracy po wdrożeniu.',
            'Najczęściej pracuję z <span class="c-amber">małymi biznesami</span>, które chcą mieć solidną stronę, dedykowane narzędzie albo spokojną opiekę IT.',
            'Zależy mi na prostym kontakcie, rozsądnym podejściu i efekcie, który daje poczucie, że kupujesz <span class="c-blue">dobry produkt</span>, a nie przypadkową usługę.'
          ]),
          cards([
            ['model współpracy', 'zdalnie, konkretnie, bez niepotrzebnego chaosu'],
            ['kontakt', 'pracujesz bezpośrednio ze mną'],
            ['priorytet', 'jakość, czytelność i stabilność']
          ])
        ]
      },
      {
        command: 'ls uslugi/',
        lines: [
          line('<span class="c-blue">[ usługi ]</span>'),
          cards([
            ['strony www', 'od 1000 zł. Lekkie strony dla małych firm, nastawione na estetykę, czytelność i szybki kontakt.'],
            ['aplikacje Python', 'narzędzia desktopowe, automatyzacje i rozwiązania pod konkretny proces.'],
            ['aplikacje Swift', 'prototypy i aplikacje pod środowisko Apple.'],
            ['opieka IT', 'od 300 zł / mies. Stałe wsparcie informatyczne dla małych biznesów.'],
            ['administracja sieci', 'konfiguracja, porządkowanie i utrzymanie środowiska sieciowego.'],
            ['wdrożenia i poprawki', 'doprowadzanie istniejących projektów do porządku i używalności.']
          ]),
          muted('Wpisz `cennik`, `kontakt` albo nazwę projektu, aby przejść dalej.')
        ]
      },
      {
        command: 'open projekty',
        lines: [
          line('<span class="c-blue">[ projekty ]</span>'),
          block([
            'Wpisz <span class="c-green">strzelca.pl</span>, <span class="c-green">get-dog.com</span> albo <span class="c-green">sredzka-korona.pl</span>, aby zobaczyć opis projektu.',
            'Każdy projekt pokazuje trochę inny kierunek: <span class="c-amber">portal / marketplace</span>, <span class="c-amber">landing promocyjny</span>, <span class="c-amber">system rezerwacyjny</span>.'
          ])
        ]
      },
      {
        command: 'cat cennik.txt',
        lines: [
          line('<span class="c-blue">[ orientacyjny cennik ]</span>'),
          block([
            '<span class="c-green">strony internetowe</span> — od 1000 zł',
            '<span class="c-green">opieka informatyczna</span> — od 300 zł / mies.',
            '<span class="c-green">aplikacje i wdrożenia</span> — wycena indywidualna po krótkim opisie potrzeb',
            'Najwygodniej będzie, jeśli od razu podasz <span class="c-amber">zakres</span>, <span class="c-amber">budżet</span> i <span class="c-amber">termin</span>.'
          ])
        ]
      },
      {
        command: 'cat proces.txt',
        lines: [
          line('<span class="c-blue">[ jak pracuję ]</span>'),
          cards([
            ['1. analiza', 'krótko ustalamy, czego naprawdę potrzebujesz i co ma dać efekt biznesowy.'],
            ['2. projekt', 'proponuję kierunek, zakres i sposób realizacji.'],
            ['3. wdrożenie', 'buduję rozwiązanie i dopinam detale techniczne.'],
            ['4. wsparcie', 'po wdrożeniu mogę dalej prowadzić opiekę i rozwój.']
          ])
        ]
      },
      {
        command: 'contact --init',
        lines: [
          line('<span class="c-blue">[ kontakt ]</span>'),
          block([
            'Możesz wysłać <span class="c-green">formularz</span> albo zostawić numer w opcji <span class="c-green">umów rozmowę</span> — oddzwonię, gdy będę wolny.',
            'Jeśli formularz nie zadziała, skontaktuj się bezpośrednio: <span class="c-amber">57 57 57 817</span> / <span class="c-amber">igor.janicki27@gmail.com</span>.'
          ]),
          { type: 'contact-forms' }
        ]
      },
      {
        command: 'echo gotowe',
        lines: [
          line('<span class="c-green">Sesja zakończona.</span>'),
          block([
            'Masz już komplet: <span class="c-blue">o mnie</span>, <span class="c-blue">usługi</span>, <span class="c-blue">projekty</span> i <span class="c-blue">kontakt</span>.',
            'Najkrótsza droga: wpisz <span class="c-amber">formularz</span> albo kliknij przycisk <span class="c-amber">kontakt</span>.'
          ])
        ]
      }
    ],
    projectDetails: {
      'strzelca.pl': [
        line('<span class="c-blue">[ strzelca.pl ]</span>'),
        block([
          'Prywatny projekt poświęcony <span class="c-green">militariom</span> i środowisku strzelców sportowych oraz kolekcjonerskich.',
          'To nie jest zwykła wizytówka. Projekt obejmuje <span class="c-amber">sklep</span>, <span class="c-amber">blog</span>, <span class="c-amber">marketplace</span>, mikropłatności i konta użytkowników.',
          'Najważniejszy wyróżnik: budowa większego ekosystemu, a nie pojedynczej podstrony.'
        ])
      ],
      'get-dog.com': [
        line('<span class="c-blue">[ get-dog.com ]</span>'),
        block([
          'Strona reklamująca aplikację, skierowana do użytkowników <span class="c-green">macOS</span>.',
          'Założenie było proste: ma być <span class="c-amber">tanio</span>, <span class="c-amber">czytelnie</span> i <span class="c-amber">ładnie wizualnie</span>, z gotowymi plikami do pobrania.',
          'To dobry przykład projektu, w którym liczy się czysta komunikacja i szybkie przejście do akcji.'
        ])
      ],
      'sredzka-korona.pl': [
        line('<span class="c-blue">[ sredzka-korona.pl ]</span>'),
        block([
          'Strona dla hotelu, restauracji i imprez okolicznościowych.',
          'Poza samą prezentacją oferty powstał tam <span class="c-green">autorski system rezerwacyjny</span> oraz <span class="c-green">panel administratorski</span> do obsługi strony.',
          'To przykład projektu, w którym warstwa wizualna musi iść w parze z realną funkcjonalnością biznesową.'
        ])
      ]
    },
    messages: {
      help: '> dostępne komendy: pomoc, dalej, wstecz, o mnie, usługi, projekty, kontakt, cennik, jak pracuję, formularz, oddzwon, telefon, email, jasny, ciemny, english, strzelca.pl, get-dog.com, sredzka-korona.pl',
      copiedPhone: '> numer telefonu skopiowany.',
      copiedEmail: '> adres e-mail skopiowany.',
      validation: '> uzupełnij wymagane pola formularza.',
      sending: '> trwa wysyłanie wiadomości...',
      success: '> wiadomość została wysłana pomyślnie.',
      callbackSuccess: '> prośba o oddzwonienie została wysłana.',
      error: '> formularz niedostarczony. prosimy o kontakt: 57 57 57 817 lub igor.janicki27@gmail.com',
      resume: '> wykryto ostatnią sesję. chcesz kontynuować czy zacząć od początku?',
      continueBtn: 'kontynuuj',
      restartBtn: 'od początku',
      unknown: '> nieznana komenda. wpisz `pomoc`.'
    }
  },
  en: {
    title: 'i-JANICKI — Websites, apps and IT support',
    description: 'i-JANICKI builds websites, Python and Swift apps, and supports small businesses with practical IT care.',
    meta: 'session active',
    next: 'next',
    prev: 'back',
    contact: 'contact',
    callback: 'schedule call',
    boot: ['boot :: i-JANICKI', 'loading modules...', 'web / python / swift / it-care', 'status :: ready'],
    commandsLabel: ['help','next','back','about','services','projects','contact','pricing','workflow','strzelca.pl','get-dog.com','sredzka-korona.pl','form','callback','light','dark','polish','phone','email'],
    steps: [
      { command: './start', lines: [line('Hello. My name is <span class="c-blue">Igor Janicki</span>.','line is-success'), block(['I build <span class="c-green">websites</span>, <span class="c-green">Python</span> and <span class="c-green">Swift</span> apps, and provide <span class="c-amber">IT care</span> for small businesses.','This website works like a <span class="c-blue">raw terminal</span> — clear, direct and stripped of unnecessary decoration.','You can move forward using the <span class="c-amber">button</span>, <span class="c-amber">Enter</span>, a <span class="c-amber">command</span> or the <span class="c-amber">mouse wheel</span>.']), muted('Type `help` to see commands.')] },
      { command: 'cat about.txt', lines: [line('<span class="c-blue">[ about ]</span>'), block(['I build things that should <span class="c-green">look strong</span>, <span class="c-green">work reliably</span> and stay practical after launch.','I mostly work with <span class="c-amber">small businesses</span> that need a solid website, a custom tool or ongoing IT support.','I care about direct communication, sensible solutions and an effect that feels like a <span class="c-blue">good product</span>, not a random service.']), cards([['work model','remote, direct, no chaos'],['contact','you work directly with me'],['priority','quality, clarity, stability']])] },
      { command: 'ls services/', lines: [line('<span class="c-blue">[ services ]</span>'), cards([['websites','from 1000 PLN. Clean sites for small companies focused on clarity and contact.'],['Python apps','desktop tools, automation and process-focused solutions.'],['Swift apps','apps and prototypes for the Apple environment.'],['IT care','from 300 PLN / month. Ongoing support for small businesses.'],['network administration','setup, cleanup and maintenance of network environments.'],['fixes and relaunches','turning existing projects into something stable and usable.']]), muted('Type `pricing`, `contact` or a project name to continue.')] },
      { command: 'open projects', lines: [line('<span class="c-blue">[ projects ]</span>'), block(['Type <span class="c-green">strzelca.pl</span>, <span class="c-green">get-dog.com</span> or <span class="c-green">sredzka-korona.pl</span> to see a project summary.','Each one shows a different direction: <span class="c-amber">portal / marketplace</span>, <span class="c-amber">promo landing page</span>, <span class="c-amber">booking system</span>.'])] },
      { command: 'cat pricing.txt', lines: [line('<span class="c-blue">[ pricing ]</span>'), block(['<span class="c-green">websites</span> — from 1000 PLN','<span class="c-green">IT care</span> — from 300 PLN / month','<span class="c-green">apps and implementations</span> — custom quote after a short project brief','The fastest way is to include your <span class="c-amber">scope</span>, <span class="c-amber">budget</span> and <span class="c-amber">timeline</span>.'])] },
      { command: 'cat workflow.txt', lines: [line('<span class="c-blue">[ workflow ]</span>'), cards([['1. analysis','we define what you actually need and what business effect matters.'],['2. concept','I propose the direction, scope and implementation path.'],['3. delivery','I build the solution and finish technical details.'],['4. support','after launch I can keep supporting and improving it.']])] },
      { command: 'contact --init', lines: [line('<span class="c-blue">[ contact ]</span>'), block(['You can send the <span class="c-green">form</span> or leave your number using <span class="c-green">schedule call</span> — I will call back when I am free.','If the form fails, contact me directly: <span class="c-amber">57 57 57 817</span> / <span class="c-amber">igor.janicki27@gmail.com</span>.']), { type: 'contact-forms' }] },
      { command: 'echo done', lines: [line('<span class="c-green">Session completed.</span>'), block(['You now have the full picture: <span class="c-blue">about</span>, <span class="c-blue">services</span>, <span class="c-blue">projects</span> and <span class="c-blue">contact</span>.','Fastest path: type <span class="c-amber">form</span> or press <span class="c-amber">contact</span>.'])] }
    ],
    projectDetails: {
      'strzelca.pl': [line('<span class="c-blue">[ strzelca.pl ]</span>'), block(['A private project focused on <span class="c-green">military and shooting</span> topics for sports shooters and collectors.','It goes beyond a showcase site: <span class="c-amber">store</span>, <span class="c-amber">blog</span>, <span class="c-amber">marketplace</span>, micropayments and user accounts.','The key point is building a broader ecosystem, not just a single website.'])],
      'get-dog.com': [line('<span class="c-blue">[ get-dog.com ]</span>'), block(['A marketing page for an app aimed at <span class="c-green">macOS</span> users.','The goal was simple: <span class="c-amber">low-cost</span>, <span class="c-amber">clear</span> and <span class="c-amber">visually clean</span>, with downloadable files available right away.','A good example of a project where communication and quick action matter most.'])],
      'sredzka-korona.pl': [line('<span class="c-blue">[ sredzka-korona.pl ]</span>'), block(['A website for a hotel, restaurant and event venue.','Beyond presenting the offer, it includes a <span class="c-green">custom booking system</span> and an <span class="c-green">admin panel</span> for managing the site.','It shows how visual presentation should support real business functionality.'])]
    },
    messages: {
      help: '> available commands: help, next, back, about, services, projects, contact, pricing, workflow, form, callback, phone, email, light, dark, polish, strzelca.pl, get-dog.com, sredzka-korona.pl',
      copiedPhone: '> phone number copied.',
      copiedEmail: '> e-mail copied.',
      validation: '> fill in the required fields.',
      sending: '> sending message...',
      success: '> message sent successfully.',
      callbackSuccess: '> callback request sent successfully.',
      error: '> form delivery failed. please contact: 57 57 57 817 or igor.janicki27@gmail.com',
      resume: '> previous session detected. continue or start from scratch?',
      continueBtn: 'continue',
      restartBtn: 'restart',
      unknown: '> unknown command. type `help`.'
    }
  }
};

const state = {
  lang: 'pl',
  theme: 'dark',
  currentStep: 0,
  wheelAccumulator: 0,
  wheelLockedUntil: 0,
  touchStartY: null,
  lastSubmitAt: 0,
  bootShown: false
};

function line(html, cls = 'line') { return { type: 'line', html, cls }; }
function muted(html) { return { type: 'line', html, cls: 'line is-muted' }; }
function block(lines) { return { type: 'block', lines }; }
function cards(items) { return { type: 'cards', items }; }

function t() { return text[state.lang]; }
function totalSteps() { return t().steps.length; }

function applyMeta() {
  document.documentElement.lang = state.lang === 'pl' ? 'pl' : 'en';
  document.title = t().title;
  const desc = document.querySelector('meta[name="description"]');
  if (desc) desc.setAttribute('content', t().description);
  ui.metaLabel.textContent = t().meta;
  ui.prevBtn.textContent = t().prev;
  ui.nextBtn.textContent = t().next;
  ui.skipToContact.textContent = t().contact;
  ui.floatingContact.textContent = t().contact;
  ui.callbackShortcut.textContent = t().callback;
  ui.langToggle.textContent = state.lang === 'pl' ? 'PL / EN' : 'EN / PL';
  ui.themeToggle.textContent = state.theme === 'dark' ? 'dark' : 'light';
  renderLegend();
  updateCounter();
}

function renderLegend() {
  ui.commandLegend.innerHTML = '';
  t().commandsLabel.forEach(cmd => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'inline-action';
    b.textContent = cmd;
    b.dataset.command = cmd;
    ui.commandLegend.appendChild(b);
  });
}

function updateCounter() {
  ui.stepCounter.textContent = `${String(state.currentStep + 1).padStart(2, '0')} / ${String(totalSteps()).padStart(2, '0')}`;
}

function renderCurrentStep() {
  const step = t().steps[state.currentStep];
  ui.output.innerHTML = '';
  appendLine(`igor@i-janicki:~$ ${step.command}`, 'line is-command');
  step.lines.forEach(item => renderItem(item));
  bindDynamicForms();
  saveSession();
  updateCounter();
  scrollOutputTop();
}

function appendLine(html, cls='line') {
  const div = document.createElement('div');
  div.className = cls;
  div.innerHTML = html;
  ui.output.appendChild(div);
}

function renderItem(item) {
  if (!item) return;
  if (item.type === 'line') {
    appendLine(item.html, item.cls || 'line');
    return;
  }
  if (item.type === 'block') {
    const wrap = document.createElement('div');
    wrap.className = 'block';
    item.lines.forEach(entry => {
      const p = document.createElement('div');
      p.className = 'line';
      p.innerHTML = entry;
      wrap.appendChild(p);
    });
    ui.output.appendChild(wrap);
    return;
  }
  if (item.type === 'cards') {
    const grid = document.createElement('div');
    grid.className = 'block-grid';
    item.items.forEach(([title, body]) => {
      const card = document.createElement('article');
      card.className = 'minicard';
      card.innerHTML = `<h4>${title}</h4><p>${body}</p>`;
      grid.appendChild(card);
    });
    ui.output.appendChild(grid);
    return;
  }
  if (item.type === 'contact-forms') {
    const clone = ui.contactTemplate.content.cloneNode(true);
    ui.output.appendChild(clone);
  }
}

function scrollOutputTop() {
  document.querySelector('.terminal-body').scrollTo({ top: 0, behavior: 'smooth' });
}

function setStep(index) {
  state.currentStep = Math.max(0, Math.min(index, totalSteps() - 1));
  renderCurrentStep();
}
function nextStep() { setStep(state.currentStep + 1); }
function prevStep() { setStep(state.currentStep - 1); }
function openContact() { setStep(totalSteps() - 2); }

function bindDynamicForms() {
  const mainContactForm = document.getElementById('mainContactForm');
  const callbackForm = document.getElementById('callbackForm');
  const buttons = ui.output.querySelectorAll('[data-copy]');

  buttons.forEach(btn => btn.addEventListener('click', () => copyContact(btn.dataset.copy)));

  if (mainContactForm) {
    mainContactForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!mainContactForm.reportValidity()) return terminalMessage(t().messages.validation, 'line is-error');
      await submitForm(mainContactForm, false);
    });
  }
  if (callbackForm) {
    callbackForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!callbackForm.reportValidity()) return terminalMessage(t().messages.validation, 'line is-error');
      await submitForm(callbackForm, true);
    });
  }
}

async function submitForm(form, isCallback) {
  const now = Date.now();
  if (now - state.lastSubmitAt < MIN_SUBMIT_INTERVAL_MS) {
    terminalMessage(t().messages.error, 'line is-error');
    return;
  }
  state.lastSubmitAt = now;
  terminalMessage(t().messages.sending, 'line is-accent');

  const endpoint = `https://formsubmit.co/ajax/${CONTACT_EMAIL}`;
  const data = new FormData(form);
  data.append('_template', 'table');
  data.append('_autoresponse', state.lang === 'pl' ? 'Dziękuję za wiadomość. Odpowiem możliwie szybko.' : 'Thank you for your message. I will reply as soon as possible.');
  if (state.lang === 'pl') data.append('_language', 'pl');

  try {
    const res = await fetch(endpoint, { method: 'POST', body: data, headers: { 'Accept': 'application/json' } });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || json.success === 'false') throw new Error('submit failed');
    terminalMessage(isCallback ? t().messages.callbackSuccess : t().messages.success, 'line is-success');
    form.reset();
  } catch (err) {
    terminalMessage(t().messages.error, 'line is-error');
  }
}

function terminalMessage(message, cls='line is-muted') {
  appendLine(message, cls);
  const body = document.querySelector('.terminal-body');
  body.scrollTo({ top: body.scrollHeight, behavior: 'smooth' });
}

async function copyContact(kind) {
  const value = kind === 'phone' ? CONTACT_PHONE : CONTACT_EMAIL;
  try {
    await navigator.clipboard.writeText(value);
    terminalMessage(kind === 'phone' ? t().messages.copiedPhone : t().messages.copiedEmail, 'line is-success');
  } catch {
    terminalMessage(t().messages.error, 'line is-error');
  }
}

function switchLanguage(lang) {
  state.lang = lang;
  applyMeta();
  renderCurrentStep();
}

function setTheme(theme) {
  state.theme = theme;
  document.body.classList.toggle('theme-light', theme === 'light');
  applyMeta();
  saveSession();
}

function executeCommand(raw) {
  const cmd = raw.trim().toLowerCase();
  if (!cmd) return;
  appendLine(`igor@i-janicki:~$ ${escapeHtml(raw)}`, 'line is-command');

  const commands = {
    'pomoc': () => terminalMessage(t().messages.help, 'line is-muted'),
    'help': () => terminalMessage(t().messages.help, 'line is-muted'),
    'dalej': nextStep,
    'next': nextStep,
    'wstecz': prevStep,
    'back': prevStep,
    'o mnie': () => setStep(1),
    'about': () => setStep(1),
    'usługi': () => setStep(2),
    'uslugi': () => setStep(2),
    'services': () => setStep(2),
    'projekty': () => setStep(3),
    'projects': () => setStep(3),
    'kontakt': openContact,
    'contact': openContact,
    'cennik': () => setStep(4),
    'pricing': () => setStep(4),
    'jak pracuję': () => setStep(5),
    'jak pracuje': () => setStep(5),
    'workflow': () => setStep(5),
    'formularz': openContact,
    'form': openContact,
    'oddzwon': openContact,
    'callback': openContact,
    'telefon': () => copyContact('phone'),
    'phone': () => copyContact('phone'),
    'email': () => copyContact('email'),
    'jasny': () => setTheme('light'),
    'light': () => setTheme('light'),
    'ciemny': () => setTheme('dark'),
    'dark': () => setTheme('dark'),
    'english': () => switchLanguage('en'),
    'polski': () => switchLanguage('pl'),
    'polish': () => switchLanguage('pl')
  };

  if (t().projectDetails[cmd]) {
    t().projectDetails[cmd].forEach(renderItem);
    document.querySelector('.terminal-body').scrollTo({ top: document.querySelector('.terminal-body').scrollHeight, behavior: 'smooth' });
    return;
  }

  const action = commands[cmd];
  if (action) {
    action();
  } else {
    terminalMessage(t().messages.unknown, 'line is-error');
  }
}

function saveSession() {
  const payload = { step: state.currentStep, lang: state.lang, theme: state.theme, ts: Date.now() };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
}

function maybeResumeSession() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return false;
    const parsed = JSON.parse(raw);
    if (!parsed.ts || Date.now() - parsed.ts > RESUME_TTL_MS) {
      localStorage.removeItem(STORAGE_KEY);
      return false;
    }
    state.lang = parsed.lang || 'pl';
    state.theme = parsed.theme || 'dark';
    state.currentStep = Number.isInteger(parsed.step) ? parsed.step : 0;
    setTheme(state.theme);
    applyMeta();
    renderCurrentStep();
    const box = document.createElement('div');
    box.className = 'resume-box';
    const continueBtn = document.createElement('button');
    continueBtn.className = 'control-btn control-btn--primary';
    continueBtn.type = 'button';
    continueBtn.textContent = t().messages.continueBtn;
    continueBtn.addEventListener('click', () => { box.remove(); terminalMessage('> ok.', 'line is-success'); saveSession(); });
    const restartBtn = document.createElement('button');
    restartBtn.className = 'control-btn';
    restartBtn.type = 'button';
    restartBtn.textContent = t().messages.restartBtn;
    restartBtn.addEventListener('click', () => { box.remove(); setStep(0); });
    terminalMessage(t().messages.resume, 'line is-accent');
    ui.output.appendChild(box);
    box.appendChild(continueBtn);
    box.appendChild(restartBtn);
    return true;
  } catch {
    return false;
  }
}

async function runBoot() {
  if (state.bootShown) return;
  state.bootShown = true;
  ui.bootText.textContent = '';
  ui.bootOverlay.classList.add('is-visible');
  for (const row of t().boot) {
    ui.bootText.textContent += `${row}\n`;
    await sleep(280);
  }
  await sleep(280);
  ui.bootOverlay.classList.remove('is-visible');
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function escapeHtml(str) { return str.replace(/[&<>"']/g, s => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;' }[s])); }

function bindEvents() {
  ui.nextBtn.addEventListener('click', nextStep);
  ui.prevBtn.addEventListener('click', prevStep);
  ui.skipToContact.addEventListener('click', openContact);
  ui.floatingContact.addEventListener('click', openContact);
  ui.callbackShortcut.addEventListener('click', openContact);
  ui.langToggle.addEventListener('click', () => switchLanguage(state.lang === 'pl' ? 'en' : 'pl'));
  ui.themeToggle.addEventListener('click', () => setTheme(state.theme === 'dark' ? 'light' : 'dark'));

  ui.commandLegend.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-command]');
    if (!btn) return;
    executeCommand(btn.dataset.command);
  });

  document.querySelectorAll('[data-copy]').forEach(btn => btn.addEventListener('click', () => copyContact(btn.dataset.copy)));

  ui.commandInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const value = ui.commandInput.value;
      ui.commandInput.value = '';
      executeCommand(value);
    }
  });

  window.addEventListener('keydown', (e) => {
    if (document.activeElement === ui.commandInput || ['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)) return;
    if (e.key === 'ArrowDown' || e.key === 'PageDown' || e.key === ' ') { e.preventDefault(); nextStep(); }
    if (e.key === 'ArrowUp' || e.key === 'PageUp') { e.preventDefault(); prevStep(); }
  });

  window.addEventListener('wheel', (e) => {
    const now = Date.now();
    if (now < state.wheelLockedUntil) return;
    state.wheelAccumulator += e.deltaY;
    if (Math.abs(state.wheelAccumulator) < 110) return;
    if (state.wheelAccumulator > 0) nextStep(); else prevStep();
    state.wheelAccumulator = 0;
    state.wheelLockedUntil = now + 520;
  }, { passive: true });

  window.addEventListener('touchstart', (e) => {
    state.touchStartY = e.touches[0]?.clientY ?? null;
  }, { passive: true });

  window.addEventListener('touchend', (e) => {
    if (state.touchStartY == null) return;
    const endY = e.changedTouches[0]?.clientY ?? state.touchStartY;
    const diff = state.touchStartY - endY;
    if (Math.abs(diff) > 70) {
      if (diff > 0) nextStep(); else prevStep();
    }
    state.touchStartY = null;
  }, { passive: true });
}

(async function init() {
  applyMeta();
  setTheme(state.theme);
  bindEvents();
  await runBoot();
  const resumed = maybeResumeSession();
  if (!resumed) renderCurrentStep();
})();
