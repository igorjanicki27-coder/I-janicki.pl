const dictionary = {
  pl: {
    floating_contact: 'Przejdź do kontaktu',
    eyebrow: 'Terminal premium dla nowoczesnych usług IT',
    hero_title: 'Strony, aplikacje i opieka IT, które robią dobre pierwsze wrażenie i dobrze działają.',
    hero_lead: 'Projektuję rozwiązania dla małych biznesów: od dopracowanych stron internetowych, przez aplikacje Python i Swift, po wsparcie IT oraz administrację sieci.',
    chip_networks: 'Sieci',
    chip_support: 'Opieka IT',
    skip_button: 'Pomiń animacje',
    project_label: 'Wybrane projekty',
    field_name: 'imię',
    field_email: 'e-mail',
    field_budget: 'budżet',
    field_description: 'opis projektu',
    send_button: 'Wyślij zapytanie',
    prev_button: 'Wstecz',
    next_button: 'Dalej',
    nav_hint: 'Scroll, Enter lub kliknij Dalej',
    footer_mode: 'Zdalnie dla małych biznesów',
    sent_ok: 'Wiadomość została wysłana pomyślnie. Odpowiem możliwie szybko.',
    sent_error: 'Nie udało się wysłać wiadomości. Spróbuj ponownie lub napisz bezpośrednio na maila.',
    sending: 'Wysyłanie wiadomości...',
    steps: [
      { style: 'line-soft', text: 'boot sequence :: i-JANICKI premium terminal' },
      { style: 'line-muted', text: 'ładowanie doświadczenia, usług i projektów...' },
      { style: 'line-title', text: 'Witaj. Nazywam się Igor Janicki.' },
      { style: 'line-soft', text: 'Tworzę strony internetowe, aplikacje na zamówienie oraz zapewniam opiekę informatyczną dla małych biznesów.' },
      { style: 'line-muted', text: 'Pracuję zdalnie. Stawiam na prostotę, czytelność i efekt jakości już od pierwszego kontaktu.' },
      { style: 'line-title', text: 'Usługi' },
      { style: 'line-soft', text: '• strony HTML/CSS\n• aplikacje Python\n• aplikacje Swift\n• administracja sieci\n• bieżące wsparcie IT' },
      { style: 'line-title', text: 'Jak pracuję' },
      { style: 'line-soft', text: 'Najpierw rozumiem Twój biznes. Potem projektuję rozwiązanie, które wygląda profesjonalnie, działa sprawnie i nie komplikuje codziennej pracy.' },
      { style: 'line-title', text: 'Projekty' },
      { style: 'line-muted', text: 'Poniżej znajdziesz wybrane realizacje.' },
      { style: 'line-title', text: 'Kontakt' },
      { style: 'line-soft', text: 'Opisz krótko, czego potrzebujesz. Możesz zostawić imię, e-mail, budżet i zakres projektu.' },
      { style: 'line-success', text: 'formularz gotowy :: czekam na Twoją wiadomość' }
    ],
    projects: [
      {
        meta: 'Portal / ekosystem',
        title: 'strzelca.pl',
        desc: 'Rozbudowany projekt internetowy z naciskiem na strukturę, użyteczność i rozwój wielu obszarów w jednym ekosystemie.',
        link: 'Otwórz projekt',
        href: 'https://strzelca.pl'
      },
      {
        meta: 'Produkt webowy',
        title: 'get-dog.com',
        desc: 'Nowoczesna realizacja webowa z naciskiem na czytelny przekaz, prostą ścieżkę użytkownika i estetykę produktu.',
        link: 'Otwórz projekt',
        href: 'https://get-dog.com'
      },
      {
        meta: 'Strona biznesowa',
        title: 'Sredzka-Korona.pl',
        desc: 'Serwis nastawiony na prezentację oferty i sprawny kontakt z klientem, z priorytetem na czytelność i wiarygodny odbiór marki.',
        link: 'Otwórz projekt',
        href: 'https://sredzka-korona.pl'
      }
    ]
  },
  en: {
    floating_contact: 'Jump to contact',
    eyebrow: 'Premium terminal for modern IT services',
    hero_title: 'Websites, apps and IT support that make a strong first impression and work reliably.',
    hero_lead: 'I build solutions for small businesses: polished websites, Python and Swift apps, IT support and network administration.',
    chip_networks: 'Networks',
    chip_support: 'IT support',
    skip_button: 'Skip animations',
    project_label: 'Selected projects',
    field_name: 'name',
    field_email: 'e-mail',
    field_budget: 'budget',
    field_description: 'project brief',
    send_button: 'Send inquiry',
    prev_button: 'Back',
    next_button: 'Next',
    nav_hint: 'Scroll, press Enter or click Next',
    footer_mode: 'Remote work for small businesses',
    sent_ok: 'Message sent successfully. I will get back to you as soon as possible.',
    sent_error: 'The message could not be sent. Please try again or contact me directly by e-mail.',
    sending: 'Sending message...',
    steps: [
      { style: 'line-soft', text: 'boot sequence :: i-JANICKI premium terminal' },
      { style: 'line-muted', text: 'loading experience, services and selected work...' },
      { style: 'line-title', text: 'Hello. My name is Igor Janicki.' },
      { style: 'line-soft', text: 'I create custom websites, applications and ongoing IT support for small businesses.' },
      { style: 'line-muted', text: 'I work remotely and focus on clarity, simplicity and a strong premium feel from the first interaction.' },
      { style: 'line-title', text: 'Services' },
      { style: 'line-soft', text: '• HTML/CSS websites\n• Python applications\n• Swift applications\n• network administration\n• ongoing IT support' },
      { style: 'line-title', text: 'How I work' },
      { style: 'line-soft', text: 'First I understand your business. Then I design a solution that looks professional, works smoothly and stays practical in day-to-day use.' },
      { style: 'line-title', text: 'Projects' },
      { style: 'line-muted', text: 'Below you can see selected work.' },
      { style: 'line-title', text: 'Contact' },
      { style: 'line-soft', text: 'Briefly describe what you need. You can leave your name, e-mail, budget and project scope.' },
      { style: 'line-success', text: 'contact form ready :: waiting for your message' }
    ],
    projects: [
      {
        meta: 'Portal / ecosystem',
        title: 'strzelca.pl',
        desc: 'A broad web project focused on structure, usability and scalable growth across multiple areas in one ecosystem.',
        link: 'Open project',
        href: 'https://strzelca.pl'
      },
      {
        meta: 'Web product',
        title: 'get-dog.com',
        desc: 'A modern web build focused on clear communication, simple user flow and product-grade presentation.',
        link: 'Open project',
        href: 'https://get-dog.com'
      },
      {
        meta: 'Business website',
        title: 'Sredzka-Korona.pl',
        desc: 'A business-facing website designed to present the offer clearly and make customer contact frictionless and credible.',
        link: 'Open project',
        href: 'https://sredzka-korona.pl'
      }
    ]
  }
};

const state = {
  lang: 'pl',
  index: -1,
  lock: false,
  typing: null,
  projectShown: false,
  formShown: false
};

const terminalLines = document.getElementById('terminalLines');
const projectCard = document.getElementById('projectCard');
const projectGrid = document.getElementById('projectGrid');
const contactForm = document.getElementById('contactForm');
const formStatus = document.getElementById('formStatus');
const langToggle = document.getElementById('langToggle');
const nextButton = document.getElementById('nextButton');
const prevButton = document.getElementById('prevButton');
const skipButton = document.getElementById('skipButton');
const quickJump = document.getElementById('quickJump');
const terminalBody = document.getElementById('terminalBody');
const sendButton = document.getElementById('sendButton');
const year = document.getElementById('year');

year.textContent = new Date().getFullYear();

function t(key) {
  return dictionary[state.lang][key];
}

function applyTranslations() {
  document.documentElement.lang = state.lang;
  document.querySelector('[data-lang-indicator]').textContent = state.lang.toUpperCase();
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    el.textContent = t(el.dataset.i18n);
  });
  renderProgress();
  renderProjects();
  updateFormPlaceholders();
}

function updateFormPlaceholders() {
  const budget = contactForm.querySelector('input[name="budget"]');
  const message = contactForm.querySelector('textarea[name="message"]');
  budget.placeholder = state.lang === 'pl' ? 'np. 3000–7000 PLN' : 'e.g. 3000–7000 PLN';
  message.placeholder = state.lang === 'pl'
    ? 'Napisz, czego potrzebujesz, jaki jest cel projektu i czego oczekujesz.'
    : 'Describe what you need, the project goal and what you expect.';
}

function clearTerminal() {
  if (state.typing) clearInterval(state.typing);
  state.typing = null;
  terminalLines.innerHTML = '';
  projectCard.hidden = true;
  contactForm.hidden = true;
  formStatus.textContent = '';
  state.index = -1;
  state.projectShown = false;
  state.formShown = false;
}

function createLine(step, instant = false) {
  return new Promise((resolve) => {
    const line = document.createElement('div');
    line.className = `terminal-line ${step.style || ''}`.trim();

    const prompt = document.createElement('span');
    prompt.className = 'prompt';
    prompt.textContent = '›';

    const content = document.createElement('span');
    content.className = 'content';

    line.append(prompt, content);
    terminalLines.appendChild(line);
    terminalBody.scrollTop = terminalBody.scrollHeight;

    if (instant || step.text.length < 6) {
      content.textContent = step.text;
      resolve();
      return;
    }

    let i = 0;
    content.classList.add('typing-cursor');
    state.typing = setInterval(() => {
      content.textContent = step.text.slice(0, i + 1);
      i += 1;
      terminalBody.scrollTop = terminalBody.scrollHeight;
      if (i >= step.text.length) {
        clearInterval(state.typing);
        state.typing = null;
        content.classList.remove('typing-cursor');
        resolve();
      }
    }, step.style === 'line-title' ? 18 : 10);
  });
}

function renderProjects() {
  projectGrid.innerHTML = '';
  dictionary[state.lang].projects.forEach((project) => {
    const template = document.getElementById('projectTemplate');
    const node = template.content.cloneNode(true);
    node.querySelector('.project-meta').textContent = project.meta;
    node.querySelector('h3').textContent = project.title;
    node.querySelector('p').textContent = project.desc;
    const link = node.querySelector('.project-link');
    link.textContent = project.link;
    link.href = project.href;
    projectGrid.appendChild(node);
  });
}

function revealSpecialBlocks() {
  if (state.index >= 10 && !state.projectShown) {
    renderProjects();
    projectCard.hidden = false;
    state.projectShown = true;
  }
  if (state.index >= 13 && !state.formShown) {
    contactForm.hidden = false;
    state.formShown = true;
  }
}

async function goNext(instant = false) {
  const steps = dictionary[state.lang].steps;
  if (state.lock || state.index >= steps.length - 1) return;
  state.lock = true;
  state.index += 1;
  await createLine(steps[state.index], instant);
  revealSpecialBlocks();
  renderProgress();
  state.lock = false;
}

async function jumpTo(targetIndex) {
  if (state.lock) return;
  if (targetIndex < -1) targetIndex = -1;
  clearTerminal();
  const steps = dictionary[state.lang].steps;
  for (let i = 0; i <= targetIndex && i < steps.length; i += 1) {
    state.index = i - 1;
    await goNext(true);
  }
  renderProgress();
}

function renderProgress() {
  const steps = dictionary[state.lang].steps;
  prevButton.disabled = state.index <= -1;
  nextButton.disabled = state.index >= steps.length - 1 || state.lock;
}

function debounce(fn, wait = 420) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

const onWheelNext = debounce((event) => {
  const formActive = !contactForm.hidden && document.activeElement && contactForm.contains(document.activeElement);
  if (formActive && terminalBody.scrollTop + terminalBody.clientHeight < terminalBody.scrollHeight - 8) return;
  if (event.deltaY > 0) goNext();
  if (event.deltaY < 0 && terminalBody.scrollTop <= 0) jumpTo(state.index - 1);
}, 260);

langToggle.addEventListener('click', async () => {
  state.lang = state.lang === 'pl' ? 'en' : 'pl';
  applyTranslations();
  const current = state.index;
  await jumpTo(current);
});

nextButton.addEventListener('click', () => goNext());
prevButton.addEventListener('click', () => jumpTo(state.index - 1));
skipButton.addEventListener('click', async () => {
  await jumpTo(dictionary[state.lang].steps.length - 1);
});
quickJump.addEventListener('click', async (event) => {
  event.preventDefault();
  await jumpTo(dictionary[state.lang].steps.length - 1);
  contactForm.scrollIntoView({ behavior: 'smooth', block: 'end' });
  const firstInput = contactForm.querySelector('input[name="name"]');
  if (firstInput) firstInput.focus();
});

window.addEventListener('keydown', (event) => {
  const tag = document.activeElement?.tagName;
  const editing = tag === 'INPUT' || tag === 'TEXTAREA';
  if (editing) return;
  if (event.key === 'Enter' || event.key === ' ' || event.key === 'ArrowDown' || event.key === 'PageDown') {
    event.preventDefault();
    goNext();
  }
  if (event.key === 'ArrowUp' || event.key === 'PageUp') {
    event.preventDefault();
    jumpTo(state.index - 1);
  }
});

window.addEventListener('wheel', onWheelNext, { passive: true });

contactForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  formStatus.textContent = t('sending');
  formStatus.className = 'form-status';
  sendButton.disabled = true;

  try {
    const response = await fetch('https://formsubmit.co/ajax/igor.janicki27@gmail.com', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({
        name: contactForm.name.value,
        email: contactForm.email.value,
        budget: contactForm.budget.value,
        message: contactForm.message.value,
        _subject: 'Nowe zapytanie z i-janicki.pl',
        _captcha: 'false',
        _template: 'table'
      })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.success === 'false') throw new Error('send_error');

    formStatus.textContent = t('sent_ok');
    formStatus.className = 'form-status';
    contactForm.reset();

    const confirmStep = { style: 'line-success', text: state.lang === 'pl' ? 'wiadomość wysłana :: dziękuję za kontakt' : 'message sent :: thank you for reaching out' };
    await createLine(confirmStep, true);
  } catch (error) {
    formStatus.textContent = t('sent_error');
    formStatus.className = 'form-status';
  } finally {
    sendButton.disabled = false;
  }
});

applyTranslations();
goNext();
