i-JANICKI — premium terminal site

Co jest w paczce:
- index.html
- styles.css
- script.js

Jak uruchomić:
1. wrzuć pliki na hosting
2. otwórz index.html
3. gotowe

Formularz:
- formularz wysyła wiadomości przez FormSubmit na: igor.janicki27@gmail.com
- przy pierwszym użyciu FormSubmit może wysłać mail aktywacyjny na tę skrzynkę
- kliknij link aktywacyjny, aby formularz działał produkcyjnie

Co już jest gotowe:
- wersja PL/EN
- premium terminal one-page
- nawigacja: scroll / Enter / spacja / przyciski
- floating contact button
- sekcje: o mnie / usługi / projekty / kontakt
- realna wysyłka formularza
- meta SEO + schema

Co możesz łatwo podmienić:
- treści w script.js
- kolory i wygląd w styles.css
- tytuły i meta w index.html
