const SESSION_KEY = 'ijanicki_terminal_session_v3';
const SESSION_TTL = 5 * 60 * 1000;
const bootLog = document.getElementById('boot-log');
const bootFill = document.getElementById('boot-progress-fill');
const bootScreen = document.getElementById('boot-screen');
const resumeModal = document.getElementById('resume-modal');
const output = document.getElementById('terminal-output');
const nextBtn = document.getElementById('next-btn');
const prevBtn = document.getElementById('prev-btn');
const commandInput = document.getElementById('command-input');
const progressIndicator = document.getElementById('progress-indicator');
const legend = document.getElementById('legend');
const langToggle = document.getElementById('lang-toggle');
const themeToggle = document.getElementById('theme-toggle');
const contactForm = document.getElementById('contact-form');
const floatingContact = document.getElementById('floating-contact');
const serviceSelect = document.getElementById('service-select');
const timelineSelect = document.getElementById('timeline-select');
const dynamicQuestionLabel = document.getElementById('dynamic-question-label');
const dynamicAnswer = document.getElementById('dynamic-answer');
const formNote = document.getElementById('form-note');
const commandPanel = document.getElementById('command-panel');

let currentLang = document.body.dataset.lang || 'pl';
let currentTheme = document.body.dataset.theme || 'dark';
let currentStep = 0;
let formStartedAt = Date.now();
let wheelLocked = false;

const translations = {
  pl: {
    brandSub: 'premium terminal experience',
    resumeTitle: 'Wykryto poprzednią sesję',
    resumeText: 'Możesz kontynuować od ostatniego kroku albo zacząć od początku.',
    resumeContinue: 'Kontynuuj',
    resumeReset: 'Zacznij od początku',
    prev: 'Wstecz',
    next: 'Dalej',
    sendBtn: 'Wyślij zapytanie',
    formService: 'Usługa',
    formBudget: 'Budżet',
    formTimeline: 'Termin',
    formName: 'Imię',
    formEmail: 'E-mail',
    formDesc: 'Opis projektu',
    formNote: 'Przy pierwszym użyciu FormSubmit może wysłać mail aktywacyjny na skrzynkę odbiorczą.',
    legend: 'Komendy:',
    services: ['Strona WWW', 'Aplikacja Python', 'Aplikacja Swift', 'Administracja sieci', 'Opieka IT'],
    timelines: ['Jak najszybciej', 'Do 2 tygodni', 'Do miesiąca', 'Elastycznie'],
    dynamicQuestions: {
      'Strona WWW': 'Jaki ma być zakres strony? (np. wizytówka, landing page, sklep)',
      'Aplikacja Python': 'Jaki problem ma rozwiązać aplikacja?',
      'Aplikacja Swift': 'Na jakie urządzenie lub platformę ma trafić aplikacja?',
      'Administracja sieci': 'Jakiej infrastruktury dotyczy zlecenie?',
      'Opieka IT': 'Ile stanowisk lub urządzeń wymaga wsparcia?'
    },
    formSuccess: 'Wiadomość została wysłana pomyślnie. Odpowiem możliwie szybko.',
    formError: 'Nie udało się wysłać wiadomości. Spróbuj ponownie lub napisz bezpośrednio na Gmail.',
    commandNotFound: 'Nieznana komenda. Wpisz „pomoc”, aby zobaczyć dostępne polecenia.',
    boot: ['inicjalizacja interfejsu...', 'ładowanie projektów...', 'konfiguracja terminala...', 'system gotowy.'],
    commands: ['pomoc', 'dalej', 'wstecz', 'o mnie', 'usługi', 'projekty', 'kontakt', 'cennik', 'jak pracuję', 'strzelca.pl', 'get-dog.com', 'sredzka-korona.pl'],
    steps: [
      {
        id: 'start',
        lines: [
          { type: 'prompt', text: 'uruchom i-janicki' },
          { type: 'html', html: `
            <div class="block fade-in">
              <div class="badge">online • premium • zdalnie</div>
              <div class="headline">Witaj. Nazywam się Igor Janicki.</div>
              <div class="subheadline">Tworzę strony WWW, aplikacje na zamówienie i zapewniam opiekę informatyczną małym biznesom. Projektuję rozwiązania tak, aby wyglądały dobrze, działały szybko i realnie pomagały w pracy.</div>
              <div class="kpis">
                <div class="card"><div class="stat-value">WWW od 1000 zł</div><div class="stat-label">strony i landing page</div></div>
                <div class="card"><div class="stat-value">Opieka od 300 zł/mies.</div><div class="stat-label">stałe wsparcie IT</div></div>
                <div class="card"><div class="stat-value">Zdalnie</div><div class="stat-label">dla małych biznesów w całej Polsce</div></div>
              </div>
            </div>` }
        ]
      },
      {
        id: 'about',
        lines: [
          { type: 'prompt', text: 'o mnie' },
          { type: 'response', text: 'Pracuję głównie z małymi biznesami, które potrzebują partnera technicznego bez zbędnej korporacyjnej otoczki.' },
          { type: 'response', text: 'Łączę estetykę premium z praktycznym wdrożeniem. Dla klienta liczy się efekt: dobra strona, sprawne narzędzie, mniej chaosu i stabilne działanie.' },
          { type: 'html', html: `
            <div class="mini-grid fade-in">
              <div class="card"><div class="card-title">HTML / CSS</div><div class="card-copy">strony, landing page, nowoczesne interfejsy</div></div>
              <div class="card"><div class="card-title">Python</div><div class="card-copy">aplikacje, automatyzacje, narzędzia desktopowe</div></div>
              <div class="card"><div class="card-title">Swift</div><div class="card-copy">rozwiązania pod ekosystem Apple</div></div>
              <div class="card"><div class="card-title">Sieci i IT</div><div class="card-copy">administracja, opieka, porządek techniczny</div></div>
            </div>` }
        ]
      },
      {
        id: 'services',
        lines: [
          { type: 'prompt', text: 'usługi' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">Strony internetowe</div><div class="card-copy">estetyczne, szybkie i czytelne strony dla firm, usług i produktów. Od prostych wizytówek po bardziej rozbudowane serwisy.</div></div>
              <div class="card"><div class="card-title">Aplikacje Python</div><div class="card-copy">narzędzia usprawniające pracę, automatyzacje i aplikacje szyte pod konkretny proces.</div></div>
              <div class="card"><div class="card-title">Aplikacje Swift</div><div class="card-copy">rozwiązania dla użytkowników Apple i projektowanie z naciskiem na jakość doświadczenia.</div></div>
              <div class="card"><div class="card-title">Administracja i opieka IT</div><div class="card-copy">bieżące wsparcie, sieci, konfiguracja środowiska i techniczny spokój dla małej firmy.</div></div>
            </div>` }
        ]
      },
      {
        id: 'pricing',
        lines: [
          { type: 'prompt', text: 'cennik' },
          { type: 'response', text: 'To orientacyjne progi startowe. Finalna wycena zależy od zakresu, terminu i poziomu złożoności.' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">Strona WWW</div><div class="stat-value">od 1000 zł</div><div class="card-copy">dla prostych stron i landing page. Większe projekty wyceniam indywidualnie.</div></div>
              <div class="card"><div class="card-title">Opieka IT</div><div class="stat-value">od 300 zł / mies.</div><div class="card-copy">dla małych firm, które chcą mieć stałe wsparcie i szybsze rozwiązywanie problemów.</div></div>
            </div>` }
        ]
      },
      {
        id: 'projects',
        lines: [
          { type: 'prompt', text: 'projekty' },
          { type: 'response', text: 'Wybrane realizacje. Wpisz nazwę projektu jako komendę, aby zobaczyć szczegóły.' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">strzelca.pl</div><div class="card-copy">portal i marketplace dla środowiska strzeleckiego</div></div>
              <div class="card"><div class="card-title">get-dog.com</div><div class="card-copy">strona reklamująca aplikację dla użytkowników macOS</div></div>
              <div class="card"><div class="card-title">sredzka-korona.pl</div><div class="card-copy">hotel, restauracja i imprezy okolicznościowe z własnym systemem rezerwacji</div></div>
              <div class="card"><div class="card-title">Tip</div><div class="card-copy">wpisz: <span class="emphasis">strzelca.pl</span>, <span class="emphasis">get-dog.com</span> albo <span class="emphasis">sredzka-korona.pl</span></div></div>
            </div>` }
        ]
      },
      {
        id: 'workflow',
        lines: [
          { type: 'prompt', text: 'jak pracuję' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">01. Analiza</div><div class="card-copy">ustalam cel, zakres i priorytety. Bez lania wody.</div></div>
              <div class="card"><div class="card-title">02. Projekt</div><div class="card-copy">dobieram strukturę, wygląd i sposób działania pod konkretną potrzebę.</div></div>
              <div class="card"><div class="card-title">03. Wdrożenie</div><div class="card-copy">buduję rozwiązanie, testuję i porządkuję szczegóły techniczne.</div></div>
              <div class="card"><div class="card-title">04. Wsparcie</div><div class="card-copy">po wdrożeniu mogę przejąć opiekę i dalszy rozwój.</div></div>
            </div>` }
        ]
      },
      {
        id: 'contact-intro',
        lines: [
          { type: 'prompt', text: 'kontakt' },
          { type: 'response', text: 'Możesz zadzwonić, napisać maila albo wysłać zapytanie bezpośrednio z terminala.' },
          { type: 'html', html: `
            <div class="contact-grid fade-in">
              <a class="card" href="tel:+48575757817"><div class="card-title">Telefon</div><div class="card-copy">57 57 57 817</div></a>
              <a class="card" href="mailto:igor.janicki27@gmail.com"><div class="card-title">E-mail</div><div class="card-copy">igor.janicki27@gmail.com</div></a>
              <div class="card"><div class="card-title">Tryb pracy</div><div class="card-copy">głównie zdalnie, elastycznie, konkretnie</div></div>
            </div>` }
        ]
      },
      {
        id: 'form',
        lines: [
          { type: 'prompt', text: 'uruchom formularz' },
          { type: 'response', text: 'Wypełnij pola poniżej. Im lepszy opis, tym trafniejsza odpowiedź i szybsza wycena.' }
        ],
        showForm: true
      }
    ],
    projectDetails: {
      'strzelca.pl': [
        'Prywatny projekt poświęcony tematyce militarnej i środowisku strzeleckiemu.',
        'Platforma dla strzelców sportowych, kolekcjonerów i osób związanych z branżą.',
        'Zaprojektowałem pełnoprawny sklep, blog, marketplace z mikropłatnościami oraz kontami użytkowników.',
        'To rozbudowany ekosystem, który łączy content, sprzedaż i funkcje społecznościowe w jednym miejscu.'
      ],
      'get-dog.com': [
        'Strona reklamująca aplikację kierowaną do użytkowników macOS.',
        'Projekt nastawiony na prostotę, niski próg wejścia i estetykę, która dobrze sprzedaje produkt.',
        'Przygotowałem lekką, ładną wizualnie stronę z zasobem plików do pobrania.',
        'Kluczowy był tu czysty przekaz i przyjazne doświadczenie użytkownika.'
      ],
      'sredzka-korona.pl': [
        'Strona dla hotelu, restauracji i organizacji imprez okolicznościowych.',
        'Projekt dla biznesu, który potrzebował nie tylko strony, ale realnego narzędzia do pracy.',
        'Stworzyłem autorski system rezerwacyjny oraz panel administracyjny obsługujący stronę.',
        'Największą wartością jest połączenie prezentacji oferty z funkcjonalnym zapleczem operacyjnym.'
      ]
    }
  },
  en: {
    brandSub: 'premium terminal experience',
    resumeTitle: 'Previous session detected',
    resumeText: 'You can continue where you left off or start from the beginning.',
    resumeContinue: 'Continue',
    resumeReset: 'Start over',
    prev: 'Back',
    next: 'Next',
    sendBtn: 'Send inquiry',
    formService: 'Service',
    formBudget: 'Budget',
    formTimeline: 'Timeline',
    formName: 'Name',
    formEmail: 'E-mail',
    formDesc: 'Project brief',
    formNote: 'On first use, FormSubmit may send an activation email to the inbox.',
    legend: 'Commands:',
    services: ['Website', 'Python App', 'Swift App', 'Network Administration', 'IT Support'],
    timelines: ['As soon as possible', 'Within 2 weeks', 'Within a month', 'Flexible'],
    dynamicQuestions: {
      'Website': 'What kind of website do you need? (e.g. landing page, company site, store)',
      'Python App': 'What problem should the application solve?',
      'Swift App': 'Which device or Apple platform is this for?',
      'Network Administration': 'What infrastructure is involved?',
      'IT Support': 'How many devices or workstations need support?'
    },
    formSuccess: 'Your message has been sent successfully. I will get back to you soon.',
    formError: 'Message could not be sent. Please try again or email me directly.',
    commandNotFound: 'Unknown command. Type “pomoc” to see available commands.',
    boot: ['initializing interface...', 'loading projects...', 'configuring terminal...', 'system ready.'],
    commands: ['pomoc', 'dalej', 'wstecz', 'o mnie', 'usługi', 'projekty', 'kontakt', 'cennik', 'jak pracuję', 'strzelca.pl', 'get-dog.com', 'sredzka-korona.pl'],
    steps: [
      {
        id: 'start',
        lines: [
          { type: 'prompt', text: 'launch i-janicki' },
          { type: 'html', html: `
            <div class="block fade-in">
              <div class="badge">online • premium • remote</div>
              <div class="headline">Hi. My name is Igor Janicki.</div>
              <div class="subheadline">I build websites, custom applications and provide IT support for small businesses. I focus on solutions that look premium, run smoothly and genuinely help day-to-day work.</div>
              <div class="kpis">
                <div class="card"><div class="stat-value">Websites from PLN 1000</div><div class="stat-label">company sites and landing pages</div></div>
                <div class="card"><div class="stat-value">Support from PLN 300/mo</div><div class="stat-label">ongoing IT care</div></div>
                <div class="card"><div class="stat-value">Remote</div><div class="stat-label">for small businesses across Poland</div></div>
              </div>
            </div>` }
        ]
      },
      {
        id: 'about',
        lines: [
          { type: 'prompt', text: 'about me' },
          { type: 'response', text: 'I mainly work with small businesses that need a reliable technical partner without corporate friction.' },
          { type: 'response', text: 'I combine premium design with practical implementation. What matters is the result: a better website, a useful tool, less chaos and stable day-to-day operation.' },
          { type: 'html', html: `
            <div class="mini-grid fade-in">
              <div class="card"><div class="card-title">HTML / CSS</div><div class="card-copy">websites, landing pages, modern interfaces</div></div>
              <div class="card"><div class="card-title">Python</div><div class="card-copy">apps, automation, desktop tools</div></div>
              <div class="card"><div class="card-title">Swift</div><div class="card-copy">solutions for the Apple ecosystem</div></div>
              <div class="card"><div class="card-title">Networks & IT</div><div class="card-copy">administration, support and technical order</div></div>
            </div>` }
        ]
      },
      {
        id: 'services',
        lines: [
          { type: 'prompt', text: 'services' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">Websites</div><div class="card-copy">clean, fast and premium websites for businesses, services and products.</div></div>
              <div class="card"><div class="card-title">Python Apps</div><div class="card-copy">tools that improve workflows, automate tasks and solve specific problems.</div></div>
              <div class="card"><div class="card-title">Swift Apps</div><div class="card-copy">Apple-focused solutions with strong attention to user experience.</div></div>
              <div class="card"><div class="card-title">Administration & IT Support</div><div class="card-copy">ongoing care, network setup and technical peace of mind for small businesses.</div></div>
            </div>` }
        ]
      },
      {
        id: 'pricing',
        lines: [
          { type: 'prompt', text: 'pricing' },
          { type: 'response', text: 'These are starting points. Final pricing depends on scope, deadline and complexity.' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">Website</div><div class="stat-value">from PLN 1000</div><div class="card-copy">for simple websites and landing pages. Larger projects are quoted individually.</div></div>
              <div class="card"><div class="card-title">IT Support</div><div class="stat-value">from PLN 300 / month</div><div class="card-copy">for small businesses that want stable support and faster problem solving.</div></div>
            </div>` }
        ]
      },
      {
        id: 'projects',
        lines: [
          { type: 'prompt', text: 'projects' },
          { type: 'response', text: 'Selected work. Type the project name as a command to open a short case study.' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">strzelca.pl</div><div class="card-copy">portal and marketplace for the shooting community</div></div>
              <div class="card"><div class="card-title">get-dog.com</div><div class="card-copy">promo website for a macOS application</div></div>
              <div class="card"><div class="card-title">sredzka-korona.pl</div><div class="card-copy">hotel and restaurant website with a custom booking system</div></div>
              <div class="card"><div class="card-title">Tip</div><div class="card-copy">type: <span class="emphasis">strzelca.pl</span>, <span class="emphasis">get-dog.com</span> or <span class="emphasis">sredzka-korona.pl</span></div></div>
            </div>` }
        ]
      },
      {
        id: 'workflow',
        lines: [
          { type: 'prompt', text: 'workflow' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">01. Discovery</div><div class="card-copy">we define goals, scope and priorities.</div></div>
              <div class="card"><div class="card-title">02. Design</div><div class="card-copy">I shape the structure, look and behavior around your actual needs.</div></div>
              <div class="card"><div class="card-title">03. Delivery</div><div class="card-copy">I build, test and refine the technical details.</div></div>
              <div class="card"><div class="card-title">04. Support</div><div class="card-copy">after launch I can handle maintenance and further development.</div></div>
            </div>` }
        ]
      },
      {
        id: 'contact-intro',
        lines: [
          { type: 'prompt', text: 'contact' },
          { type: 'response', text: 'You can call, email or send an inquiry directly from the terminal.' },
          { type: 'html', html: `
            <div class="contact-grid fade-in">
              <a class="card" href="tel:+48575757817"><div class="card-title">Phone</div><div class="card-copy">57 57 57 817</div></a>
              <a class="card" href="mailto:igor.janicki27@gmail.com"><div class="card-title">E-mail</div><div class="card-copy">igor.janicki27@gmail.com</div></a>
              <div class="card"><div class="card-title">Work mode</div><div class="card-copy">mostly remote, flexible and direct</div></div>
            </div>` }
        ]
      },
      {
        id: 'form',
        lines: [
          { type: 'prompt', text: 'launch form' },
          { type: 'response', text: 'Fill in the form below. Better details mean a better reply and a faster quote.' }
        ],
        showForm: true
      }
    ],
    projectDetails: {
      'strzelca.pl': [
        'A private project focused on military and shooting-related topics.',
        'Built for sport shooters, collectors and people connected with the niche.',
        'I designed a full store, blog, marketplace with micro-payments and user accounts.',
        'The key value is combining content, commerce and community features in one ecosystem.'
      ],
      'get-dog.com': [
        'A promotional website advertising an application for macOS users.',
        'The project focused on simplicity, low friction and visual quality.',
        'I built a lightweight and attractive site with downloadable resources.',
        'The main goal was a clear message and a polished user experience.'
      ],
      'sredzka-korona.pl': [
        'A website for a hotel, restaurant and events business.',
        'This project needed more than presentation — it needed a working business tool.',
        'I built a custom reservation system and an admin panel powering the site.',
        'The strongest part is the link between a strong front-end presence and useful operational backend.'
      ]
    }
  }
};

function t(key) {
  return translations[currentLang][key];
}

function applyStaticTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.textContent = t(el.dataset.i18n);
  });
  nextBtn.textContent = t('next');
  prevBtn.textContent = t('prev');
  formNote.textContent = t('formNote');
  floatingContact.setAttribute('aria-label', currentLang === 'pl' ? 'Przejdź do kontaktu' : 'Go to contact');
  buildLegend();
  populateFormSelects();
}

function buildLegend() {
  const commands = t('commands').map(cmd => `<code>${cmd}</code>`).join(' ');
  legend.innerHTML = `${t('legend')} ${commands}`;
}

function populateFormSelects() {
  serviceSelect.innerHTML = '';
  t('services').forEach(item => {
    const opt = document.createElement('option');
    opt.value = item;
    opt.textContent = item;
    serviceSelect.appendChild(opt);
  });
  timelineSelect.innerHTML = '';
  t('timelines').forEach(item => {
    const opt = document.createElement('option');
    opt.value = item;
    opt.textContent = item;
    timelineSelect.appendChild(opt);
  });
  updateDynamicQuestion();
}

function saveSession() {
  localStorage.setItem(SESSION_KEY, JSON.stringify({
    ts: Date.now(),
    currentStep,
    lang: currentLang,
    theme: currentTheme
  }));
}

function getSavedSession() {
  const raw = localStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (Date.now() - parsed.ts > SESSION_TTL) {
      localStorage.removeItem(SESSION_KEY);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}

function appendLine(line) {
  const block = document.createElement('div');
  block.className = 'block fade-in';
  if (line.type === 'prompt') {
    block.innerHTML = `<span class="prompt">&gt; ${line.text}</span>`;
  } else if (line.type === 'response') {
    block.innerHTML = `<div class="response">${line.text}</div>`;
  } else if (line.type === 'html') {
    block.innerHTML = line.html;
  }
  output.appendChild(block);
  output.scrollTop = output.scrollHeight;
}

function typeText(text, cb, className='response') {
  const block = document.createElement('div');
  block.className = `block ${className === 'prompt' ? 'prompt' : 'response'} fade-in`;
  const span = document.createElement('span');
  const caret = document.createElement('span');
  caret.className = 'caret';
  block.appendChild(span);
  block.appendChild(caret);
  output.appendChild(block);
  let i = 0;
  const tick = () => {
    span.textContent = (className === 'prompt' ? '> ' : '') + text.slice(0, i);
    output.scrollTop = output.scrollHeight;
    if (i < text.length) {
      i += 1;
      setTimeout(tick, 12);
    } else {
      caret.remove();
      cb && cb();
    }
  };
  tick();
}

function renderStep(index, { replace = false } = {}) {
  const steps = translations[currentLang].steps;
  if (index < 0 || index >= steps.length) return;
  currentStep = index;
  if (replace) output.innerHTML = '';
  contactForm.classList.add('hidden');
  commandPanel.classList.remove('hidden');
  const step = steps[index];

  let pos = 0;
  function nextLine() {
    if (pos >= step.lines.length) {
      if (step.showForm) {
        contactForm.classList.remove('hidden');
        commandPanel.classList.add('hidden');
        setTimeout(() => contactForm.querySelector('input,select,textarea')?.focus(), 120);
      }
      progressIndicator.textContent = `${String(index + 1).padStart(2, '0')} / ${String(steps.length).padStart(2, '0')}`;
      saveSession();
      return;
    }
    const line = step.lines[pos++];
    if (line.type === 'prompt') {
      typeText(line.text, nextLine, 'prompt');
    } else if (line.type === 'response') {
      typeText(line.text, nextLine, 'response');
    } else {
      appendLine(line);
      setTimeout(nextLine, 100);
    }
  }
  nextLine();
}

function goNext() {
  if (currentStep < translations[currentLang].steps.length - 1) renderStep(currentStep + 1, { replace: true });
}
function goPrev() {
  if (currentStep > 0) renderStep(currentStep - 1, { replace: true });
}

function renderProjectDetail(key) {
  const details = translations[currentLang].projectDetails[key];
  if (!details) return false;
  appendLine({ type: 'prompt', text: key });
  appendLine({ type: 'html', html: `<div class="card fade-in"><div class="card-title">${key}</div><div class="card-copy">${details.map(line => `<div>${line}</div>`).join('')}</div></div>` });
  return true;
}

function handleCommand(raw) {
  const cmd = raw.trim().toLowerCase();
  if (!cmd) return;
  appendLine({ type: 'prompt', text: raw });
  commandInput.value = '';

  const map = {
    'pomoc': () => appendLine({ type: 'response', text: t('commands').join(' • ') }),
    'dalej': goNext,
    'wstecz': goPrev,
    'o mnie': () => renderStep(1, { replace: true }),
    'usługi': () => renderStep(2, { replace: true }),
    'uslugi': () => renderStep(2, { replace: true }),
    'cennik': () => renderStep(3, { replace: true }),
    'projekty': () => renderStep(4, { replace: true }),
    'jak pracuję': () => renderStep(5, { replace: true }),
    'jak pracuje': () => renderStep(5, { replace: true }),
    'kontakt': () => renderStep(6, { replace: true }),
    'formularz': () => renderStep(7, { replace: true }),
    'strzelca.pl': () => renderProjectDetail('strzelca.pl'),
    'get-dog.com': () => renderProjectDetail('get-dog.com'),
    'sredzka-korona.pl': () => renderProjectDetail('sredzka-korona.pl')
  };

  if (map[cmd]) {
    map[cmd]();
  } else {
    appendLine({ type: 'response', text: t('commandNotFound') });
  }
}

function updateDynamicQuestion() {
  const selected = serviceSelect.value;
  const question = t('dynamicQuestions')[selected] || '';
  dynamicQuestionLabel.textContent = question;
  dynamicAnswer.placeholder = currentLang === 'pl' ? 'Wpisz odpowiedź…' : 'Type your answer…';
}

async function submitForm(e) {
  e.preventDefault();
  const honey = contactForm.querySelector('[name="_honey"]').value;
  if (honey) return;
  if (Date.now() - formStartedAt < 4000) {
    appendLine({ type: 'response', text: currentLang === 'pl' ? 'Chwila. Wyślij formularz po kilku sekundach.' : 'Please wait a few seconds before sending.' });
    return;
  }

  const formData = new FormData(contactForm);
  formData.append('_subject', currentLang === 'pl' ? 'Nowe zapytanie z i-janicki.pl' : 'New inquiry from i-janicki.pl');

  const sendBtn = document.getElementById('send-btn');
  sendBtn.disabled = true;
  sendBtn.textContent = currentLang === 'pl' ? 'Wysyłanie…' : 'Sending…';

  try {
    const res = await fetch('https://formsubmit.co/ajax/igor.janicki27@gmail.com', {
      method: 'POST',
      body: formData,
      headers: { 'Accept': 'application/json' }
    });
    const data = await res.json();
    if (data.success === 'true' || data.success === true) {
      appendLine({ type: 'response', text: t('formSuccess') });
      contactForm.reset();
      populateFormSelects();
      formStartedAt = Date.now();
    } else {
      appendLine({ type: 'response', text: t('formError') });
    }
  } catch {
    appendLine({ type: 'response', text: t('formError') });
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = t('sendBtn');
  }
}

async function boot() {
  const lines = t('boot');
  bootLog.textContent = '';
  for (let i = 0; i < lines.length; i++) {
    bootLog.textContent += `${lines[i]}\n`;
    bootFill.style.width = `${((i + 1) / lines.length) * 100}%`;
    await new Promise(r => setTimeout(r, 360));
  }
  await new Promise(r => setTimeout(r, 250));
  bootScreen.classList.add('hidden');

  const saved = getSavedSession();
  if (saved) {
    currentLang = saved.lang || currentLang;
    currentTheme = saved.theme || currentTheme;
    document.body.dataset.lang = currentLang;
    document.body.dataset.theme = currentTheme;
    applyStaticTranslations();
    resumeModal.classList.remove('hidden');
    document.getElementById('resume-continue').onclick = () => {
      resumeModal.classList.add('hidden');
      renderStep(saved.currentStep || 0, { replace: true });
    };
    document.getElementById('resume-reset').onclick = () => {
      clearSession();
      resumeModal.classList.add('hidden');
      renderStep(0, { replace: true });
    };
  } else {
    renderStep(0, { replace: true });
  }
}

nextBtn.addEventListener('click', goNext);
prevBtn.addEventListener('click', goPrev);
commandInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') handleCommand(commandInput.value);
});
serviceSelect.addEventListener('change', updateDynamicQuestion);
contactForm.addEventListener('submit', submitForm);
langToggle.addEventListener('click', () => {
  currentLang = currentLang === 'pl' ? 'en' : 'pl';
  document.body.dataset.lang = currentLang;
  applyStaticTranslations();
  renderStep(currentStep, { replace: true });
});
themeToggle.addEventListener('click', () => {
  currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
  document.body.dataset.theme = currentTheme;
  saveSession();
});
floatingContact.addEventListener('click', e => {
  e.preventDefault();
  renderStep(7, { replace: true });
});

document.addEventListener('keydown', e => {
  if (document.activeElement && ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) return;
  if (e.key === 'ArrowRight' || e.key === 'PageDown') goNext();
  if (e.key === 'ArrowLeft' || e.key === 'PageUp') goPrev();
  if (e.key === ' ' || e.key === 'Enter') {
    e.preventDefault();
    goNext();
  }
});

document.addEventListener('wheel', e => {
  if (wheelLocked) return;
  wheelLocked = true;
  setTimeout(() => wheelLocked = false, 650);
  if (e.deltaY > 12) goNext();
  if (e.deltaY < -12) goPrev();
}, { passive: true });

applyStaticTranslations();
boot();
