i-JANICKI v3

Pliki:
- index.html
- styles.css
- script.js

Uruchomienie:
- wrzuć pliki na hosting statyczny
- formularz korzysta z FormSubmit i wysyła na: igor.janicki27@gmail.com
- przy pierwszym teście kliknij link aktywacyjny, który może przyjść na mail

Najważniejsze funkcje:
- premium terminal one-page
- PL / EN
- dark / light
- obsługa: przyciski, scroll, Enter, spacja
- polskie komendy w terminalu
- case studies projektów po komendzie
- sekcja „jak pracuję”
- formularz z prawdziwą wysyłką
- floating contact button
- zapamiętanie sesji na 5 minut
- prosty anti-spam: honeypot + minimalny czas do wysyłki

Dostępne komendy:
- pomoc
- dalej
- wstecz
- o mnie
- usługi
- cennik
- projekty
- kontakt
- jak pracuję
- strzelca.pl
- get-dog.com
- sredzka-korona.pl

Uwagi:
- jeśli chcesz podpiąć własną domenę, wystarczy wrzucić pliki na hosting i ustawić domenę po swojej stronie
- jeśli chcesz dodać logo lub favicon, dodaj plik i podepnij go w <head>
