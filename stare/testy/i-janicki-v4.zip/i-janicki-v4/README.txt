i-JANICKI v4

Zawartość:
- index.html
- styles.css
- script.js

Co dodano względem v3:
- mocniejsze copy sprzedażowe
- bardziej dopracowany premium terminal
- lepszy układ desktop/mobile
- dodatkowe komendy języka i motywu
- lepsze case studies projektów
- szybsze CTA do kontaktu
- ukryta sekcja SEO w DOM

Wysyłka formularza:
- formularz wysyła na: igor.janicki27@gmail.com
- endpoint: https://formsubmit.co/ajax/igor.janicki27@gmail.com
- przy pierwszym użyciu FormSubmit może wymagać aktywacji przez mail

Ważne:
- jeśli chcesz własne logo lub favicon, dodaj je ręcznie do <head>
- jeśli chcesz własną domenę produkcyjną, po prostu wrzuć pliki na hosting
- jeśli chcesz podpiąć własny backend/API zamiast FormSubmit, najłatwiej podmienić fetch w script.js
