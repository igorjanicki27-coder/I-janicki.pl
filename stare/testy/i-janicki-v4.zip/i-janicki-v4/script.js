const SESSION_KEY = 'ijanicki_terminal_session_v4';
const SESSION_TTL = 5 * 60 * 1000;

const els = {
  body: document.body,
  bootScreen: document.getElementById('boot-screen'),
  bootLog: document.getElementById('boot-log'),
  bootFill: document.getElementById('boot-progress-fill'),
  resumeModal: document.getElementById('resume-modal'),
  output: document.getElementById('terminal-output'),
  nextBtn: document.getElementById('next-btn'),
  prevBtn: document.getElementById('prev-btn'),
  commandInput: document.getElementById('command-input'),
  progress: document.getElementById('progress-indicator'),
  legend: document.getElementById('legend'),
  langToggle: document.getElementById('lang-toggle'),
  themeToggle: document.getElementById('theme-toggle'),
  terminalState: document.getElementById('terminal-state'),
  contactForm: document.getElementById('contact-form'),
  serviceSelect: document.getElementById('service-select'),
  timelineSelect: document.getElementById('timeline-select'),
  dynamicQuestionLabel: document.getElementById('dynamic-question-label'),
  dynamicAnswer: document.getElementById('dynamic-answer'),
  formNote: document.getElementById('form-note'),
  commandPanel: document.getElementById('command-panel'),
  floatingContact: document.getElementById('floating-contact'),
  quickPills: document.getElementById('quick-pills')
};

let currentLang = els.body.dataset.lang || 'pl';
let currentTheme = els.body.dataset.theme || 'dark';
let currentStep = 0;
let formStartedAt = Date.now();
let wheelLock = false;
let isTyping = false;

const translations = {
  pl: {
    brandSub: 'premium terminal experience',
    resumeTitle: 'Wykryto poprzednią sesję',
    resumeText: 'Możesz kontynuować od ostatniego kroku albo zacząć od początku.',
    resumeContinue: 'Kontynuuj',
    resumeReset: 'Zacznij od początku',
    prev: 'Wstecz',
    next: 'Dalej',
    sideLabel: 'Nawigacja',
    quickAccess: 'Szybki dostęp',
    contactShort: 'Kontakt',
    sideNote: 'Pełny ekran, jedna narracja, terminalowy kontakt i szybkie komendy po polsku.',
    footerHint: 'Scroll, Enter, spacja lub komendy tekstowe.',
    formService: 'Usługa',
    formBudget: 'Budżet',
    formTimeline: 'Termin',
    formName: 'Imię',
    formEmail: 'E-mail',
    formDesc: 'Opis projektu',
    sendBtn: 'Wyślij zapytanie',
    formNote: 'Przy pierwszym użyciu FormSubmit może wysłać wiadomość aktywacyjną na skrzynkę odbiorczą.',
    formSuccess: 'Wiadomość została wysłana pomyślnie. Odpowiem możliwie szybko.',
    formError: 'Nie udało się wysłać wiadomości. Spróbuj ponownie lub napisz bezpośrednio na Gmail.',
    legendLabel: 'Dostępne komendy:',
    typingWait: 'Poczekaj chwilę, aż zakończy się animacja.',
    commandNotFound: 'Nieznana komenda. Wpisz „pomoc”, aby zobaczyć dostępne polecenia.',
    boot: ['inicjalizacja interfejsu…', 'ładowanie portfolio…', 'konfiguracja nawigacji…', 'uruchamianie formularza…', 'system gotowy.'],
    services: ['Strona WWW', 'Aplikacja Python', 'Aplikacja Swift', 'Administracja sieci', 'Opieka IT'],
    timelines: ['Jak najszybciej', 'Do 2 tygodni', 'Do miesiąca', 'Elastycznie'],
    dynamicQuestions: {
      'Strona WWW': 'Jaki typ strony Cię interesuje? (np. wizytówka, landing page, sklep)',
      'Aplikacja Python': 'Jaki proces lub problem ma rozwiązać aplikacja?',
      'Aplikacja Swift': 'Na jakie urządzenie lub platformę Apple ma trafić aplikacja?',
      'Administracja sieci': 'Jakiego środowiska lub infrastruktury dotyczy zlecenie?',
      'Opieka IT': 'Ile stanowisk lub urządzeń wymaga bieżącego wsparcia?'
    },
    commands: ['pomoc', 'dalej', 'wstecz', 'o mnie', 'usługi', 'projekty', 'kontakt', 'cennik', 'jak pracuję', 'formularz', 'jasny', 'ciemny', 'polski', 'english', 'strzelca.pl', 'get-dog.com', 'sredzka-korona.pl'],
    commandPills: ['o mnie', 'usługi', 'projekty', 'kontakt', 'cennik'],
    steps: [
      {
        id: 'start',
        state: 'storytelling',
        lines: [
          { type: 'prompt', text: 'uruchom i-janicki' },
          { type: 'html', html: `
            <div class="block fade-in">
              <div class="badge">premium • zdalnie • dla małych biznesów</div>
              <div class="headline">Dobre rozwiązania powinny wyglądać lekko i działać bez oporu.</div>
              <div class="subheadline">Nazywam się Igor Janicki. Projektuję strony internetowe, tworzę aplikacje na zamówienie i zapewniam opiekę informatyczną małym biznesom. Stawiam na jakość wykonania, przejrzystość i efekt, który realnie wspiera firmę.</div>
              <div class="kpis">
                <div class="card"><div class="stat-value">WWW od 1000 zł</div><div class="stat-label">strony firmowe, landing page i lżejsze wdrożenia sprzedażowe</div></div>
                <div class="card"><div class="stat-value">Opieka od 300 zł / mies.</div><div class="stat-label">stałe wsparcie techniczne dla małych biznesów</div></div>
                <div class="card"><div class="stat-value">HTML / Python / Swift / IT</div><div class="stat-label">pełniejsze podejście niż sama „ładna strona”</div></div>
              </div>
            </div>` }
        ]
      },
      {
        id: 'about',
        state: 'about',
        lines: [
          { type: 'prompt', text: 'o mnie' },
          { type: 'response', text: 'Pracuję głównie z małymi firmami, które chcą działać sprawniej, wyglądać lepiej i mieć porządek po technicznej stronie.' },
          { type: 'response', text: 'Nie interesuje mnie przypadkowe dokładanie efektów. Liczy się spójność, szybkość działania i narzędzie, które ma sens dla konkretnego biznesu.' },
          { type: 'html', html: `
            <div class="mini-grid fade-in">
              <div class="card"><div class="card-title">Strony WWW</div><div class="card-copy">czytelne, nowoczesne i projektowane z myślą o sprzedaży oraz zaufaniu.</div></div>
              <div class="card"><div class="card-title">Aplikacje</div><div class="card-copy">narzędzia desktopowe i rozwiązania szyte pod konkretną pracę lub proces.</div></div>
              <div class="card"><div class="card-title">Apple i Swift</div><div class="card-copy">projekty z naciskiem na estetykę, lekkość i wygodę użytkownika.</div></div>
              <div class="card"><div class="card-title">Sieci i opieka IT</div><div class="card-copy">mniej chaosu, szybsze rozwiązywanie problemów i większy spokój w codziennej pracy.</div></div>
            </div>` }
        ]
      },
      {
        id: 'services',
        state: 'services',
        lines: [
          { type: 'prompt', text: 'usługi' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">Strony internetowe</div><div class="card-copy">Od prostych stron firmowych po bardziej rozbudowane serwisy. Priorytetem jest przejrzystość, szybkość i profesjonalny odbiór marki.</div></div>
              <div class="card"><div class="card-title">Aplikacje Python</div><div class="card-copy">Automatyzacje, aplikacje desktopowe i narzędzia, które rozwiązują konkretny problem zamiast dokładania kolejnej warstwy chaosu.</div></div>
              <div class="card"><div class="card-title">Aplikacje Swift</div><div class="card-copy">Rozwiązania dla użytkowników Apple, gdzie liczy się jakość doświadczenia i dopracowanie szczegółów.</div></div>
              <div class="card"><div class="card-title">Administracja i opieka IT</div><div class="card-copy">Wsparcie techniczne, konfiguracje sieciowe i stała opieka dla firm, które chcą działać spokojniej i przewidywalniej.</div></div>
            </div>` }
        ]
      },
      {
        id: 'pricing',
        state: 'pricing',
        lines: [
          { type: 'prompt', text: 'cennik' },
          { type: 'response', text: 'To punkty wejścia. Finalna wycena zależy od zakresu, terminu, liczby funkcji i poziomu integracji.' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">Strona WWW</div><div class="stat-value">od 1000 zł</div><div class="card-copy">dla prostszych stron i landing page. Bardziej rozbudowane wdrożenia wyceniam indywidualnie.</div></div>
              <div class="card"><div class="card-title">Opieka IT</div><div class="stat-value">od 300 zł / mies.</div><div class="card-copy">dla małych biznesów, które chcą mieć stałe wsparcie i krótszą drogę do rozwiązania problemu.</div></div>
            </div>` }
        ]
      },
      {
        id: 'projects',
        state: 'projects',
        lines: [
          { type: 'prompt', text: 'projekty' },
          { type: 'response', text: 'Wybrane realizacje. Wpisz nazwę projektu jako komendę, aby otworzyć skrócone case study.' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">strzelca.pl</div><div class="card-copy">sklep, blog i marketplace dla środowiska strzeleckiego</div></div>
              <div class="card"><div class="card-title">get-dog.com</div><div class="card-copy">lekka i estetyczna strona promująca aplikację dla macOS</div></div>
              <div class="card"><div class="card-title">sredzka-korona.pl</div><div class="card-copy">strona hotelu i restauracji z autorskim systemem rezerwacji</div></div>
              <div class="card"><div class="card-title">Wskazówka</div><div class="card-copy">Wpisz: <span class="emphasis">strzelca.pl</span>, <span class="emphasis">get-dog.com</span> albo <span class="emphasis">sredzka-korona.pl</span></div></div>
            </div>` }
        ]
      },
      {
        id: 'workflow',
        state: 'workflow',
        lines: [
          { type: 'prompt', text: 'jak pracuję' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">01. Analiza</div><div class="card-copy">Ustalamy cel, priorytety i zakres. Bez zbędnego komplikowania.</div></div>
              <div class="card"><div class="card-title">02. Projekt</div><div class="card-copy">Dobieram strukturę, wygląd i logikę działania pod Twój model pracy lub sprzedaży.</div></div>
              <div class="card"><div class="card-title">03. Wdrożenie</div><div class="card-copy">Buduję rozwiązanie, dopinam technikalia i dbam o płynność działania.</div></div>
              <div class="card"><div class="card-title">04. Wsparcie</div><div class="card-copy">Po wdrożeniu mogę zostać po technicznej stronie i dbać o dalszy rozwój.</div></div>
            </div>` }
        ]
      },
      {
        id: 'contact',
        state: 'contact',
        lines: [
          { type: 'prompt', text: 'kontakt' },
          { type: 'response', text: 'Możesz zadzwonić, napisać maila albo przejść od razu do formularza i opisać swój projekt.' },
          { type: 'html', html: `
            <div class="contact-grid fade-in">
              <a class="card" href="tel:+48575757817"><div class="card-title">Telefon</div><div class="card-copy">57 57 57 817</div></a>
              <a class="card" href="mailto:igor.janicki27@gmail.com"><div class="card-title">E-mail</div><div class="card-copy">igor.janicki27@gmail.com</div></a>
              <div class="card"><div class="card-title">Tryb współpracy</div><div class="card-copy">Głównie zdalnie. Sprawnie, konkretnie i bez przerostu formy.</div></div>
            </div>` }
        ]
      },
      {
        id: 'form',
        state: 'form',
        lines: [
          { type: 'prompt', text: 'formularz' },
          { type: 'response', text: 'Wypełnij formularz poniżej. Im konkretniej opiszesz temat, tym szybciej wrócę z sensowną odpowiedzią.' }
        ],
        showForm: true
      }
    ],
    projectDetails: {
      'strzelca.pl': {
        title: 'strzelca.pl',
        kicker: 'projekt własny',
        quote: 'Rozbudowany ekosystem łączący treści, sprzedaż i funkcje społecznościowe dla środowiska związanego z militariami.',
        bullets: [
          'Strona poświęcona militariom i środowisku strzeleckiemu.',
          'Grupa docelowa: strzelcy sportowi, kolekcjonerzy i osoby związane z branżą.',
          'Zakres: pełnoprawny sklep, blog, marketplace, mikropłatności oraz konta użytkowników.',
          'To projekt, w którym warstwa wizualna musiała iść w parze z realną funkcjonalnością i rozwojem produktu.'
        ],
        metrics: ['Sklep + blog + marketplace', 'Mikropłatności i konta', 'Autorski rozwój produktu']
      },
      'get-dog.com': {
        title: 'get-dog.com',
        kicker: 'strona promująca aplikację',
        quote: 'Lekka, szybka i estetyczna strona reklamująca aplikację dla użytkowników macOS.',
        bullets: [
          'Projekt kierowany do użytkowników Apple i macOS.',
          'Cel: prosty, tani i atrakcyjny wizualnie landing, który dobrze prezentuje produkt.',
          'Zakres: strona promocyjna oraz zasób plików do pobrania.',
          'Najważniejszy był czysty przekaz, niski próg wejścia i przyjemny odbiór całości.'
        ],
        metrics: ['macOS audience', 'lekka architektura', 'czytelny przekaz']
      },
      'sredzka-korona.pl': {
        title: 'sredzka-korona.pl',
        kicker: 'hotel / restauracja / eventy',
        quote: 'Strona biznesowa połączona z autorskim systemem rezerwacyjnym i panelem administracyjnym.',
        bullets: [
          'Projekt dla hotelu, restauracji i imprez okolicznościowych.',
          'Zakres wykraczał poza samą prezentację oferty.',
          'Stworzyłem pełnoprawny, autorski system rezerwacyjny i panel administracyjny obsługujący stronę.',
          'To przykład wdrożenia, gdzie front i zaplecze operacyjne muszą działać razem.'
        ],
        metrics: ['Autorski system rezerwacji', 'Panel administracyjny', 'Strona + operacyjny backend']
      }
    }
  },
  en: {
    brandSub: 'premium terminal experience',
    resumeTitle: 'Previous session detected',
    resumeText: 'You can continue where you left off or start from the beginning.',
    resumeContinue: 'Continue',
    resumeReset: 'Start over',
    prev: 'Back',
    next: 'Next',
    sideLabel: 'Navigation',
    quickAccess: 'Quick access',
    contactShort: 'Contact',
    sideNote: 'Full screen, one narrative, terminal contact and fast text commands.',
    footerHint: 'Scroll, Enter, Space or text commands.',
    formService: 'Service',
    formBudget: 'Budget',
    formTimeline: 'Timeline',
    formName: 'Name',
    formEmail: 'E-mail',
    formDesc: 'Project brief',
    sendBtn: 'Send inquiry',
    formNote: 'On first use, FormSubmit may send an activation email.',
    formSuccess: 'Your message has been sent successfully. I will get back to you soon.',
    formError: 'The message could not be sent. Please try again or email me directly.',
    legendLabel: 'Available commands:',
    typingWait: 'Please wait until the animation finishes.',
    commandNotFound: 'Unknown command. Type “help” to see available commands.',
    boot: ['initializing interface…', 'loading portfolio…', 'configuring navigation…', 'loading contact flow…', 'system ready.'],
    services: ['Website', 'Python App', 'Swift App', 'Network Administration', 'IT Support'],
    timelines: ['As soon as possible', 'Within 2 weeks', 'Within a month', 'Flexible'],
    dynamicQuestions: {
      'Website': 'What kind of website do you need? (e.g. landing page, company site, store)',
      'Python App': 'What process or problem should the app solve?',
      'Swift App': 'Which Apple device or platform is this for?',
      'Network Administration': 'What environment or infrastructure is involved?',
      'IT Support': 'How many devices or workstations need support?'
    },
    commands: ['help', 'next', 'back', 'about', 'services', 'projects', 'contact', 'pricing', 'workflow', 'form', 'light', 'dark', 'polish', 'english', 'strzelca.pl', 'get-dog.com', 'sredzka-korona.pl'],
    commandPills: ['about', 'services', 'projects', 'contact', 'pricing'],
    steps: [
      {
        id: 'start',
        state: 'storytelling',
        lines: [
          { type: 'prompt', text: 'launch i-janicki' },
          { type: 'html', html: `
            <div class="block fade-in">
              <div class="badge">premium • remote • for small businesses</div>
              <div class="headline">Good digital work should feel light and work without friction.</div>
              <div class="subheadline">My name is Igor Janicki. I design websites, build custom apps and provide IT support for small businesses. I focus on quality, clarity and solutions that actually help a company operate better.</div>
              <div class="kpis">
                <div class="card"><div class="stat-value">Websites from PLN 1000</div><div class="stat-label">business websites, landing pages and smaller sales-focused builds</div></div>
                <div class="card"><div class="stat-value">Support from PLN 300 / month</div><div class="stat-label">ongoing technical care for small businesses</div></div>
                <div class="card"><div class="stat-value">HTML / Python / Swift / IT</div><div class="stat-label">more than just a “nice looking site”</div></div>
              </div>
            </div>` }
        ]
      },
      {
        id: 'about',
        state: 'about',
        lines: [
          { type: 'prompt', text: 'about' },
          { type: 'response', text: 'I mainly work with small businesses that want better presentation, smoother operations and more technical order.' },
          { type: 'response', text: 'I do not add effects for the sake of effects. The priority is coherence, speed and a solution that makes sense for the actual business.' },
          { type: 'html', html: `
            <div class="mini-grid fade-in">
              <div class="card"><div class="card-title">Websites</div><div class="card-copy">clean, modern and designed to build trust and support sales.</div></div>
              <div class="card"><div class="card-title">Applications</div><div class="card-copy">desktop tools and custom solutions built around a specific workflow or task.</div></div>
              <div class="card"><div class="card-title">Apple & Swift</div><div class="card-copy">projects with strong attention to aesthetics, lightness and user comfort.</div></div>
              <div class="card"><div class="card-title">Networks & IT Support</div><div class="card-copy">less chaos, faster problem solving and more daily peace of mind.</div></div>
            </div>` }
        ]
      },
      {
        id: 'services',
        state: 'services',
        lines: [
          { type: 'prompt', text: 'services' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">Websites</div><div class="card-copy">From simple business websites to more advanced services. The focus is clarity, performance and a professional brand impression.</div></div>
              <div class="card"><div class="card-title">Python Apps</div><div class="card-copy">Automation, desktop apps and tools that solve a real problem instead of adding more complexity.</div></div>
              <div class="card"><div class="card-title">Swift Apps</div><div class="card-copy">Solutions for Apple users where detail, experience and polish matter.</div></div>
              <div class="card"><div class="card-title">Administration & IT Support</div><div class="card-copy">Technical support, networking and ongoing care for businesses that want calmer operations.</div></div>
            </div>` }
        ]
      },
      {
        id: 'pricing',
        state: 'pricing',
        lines: [
          { type: 'prompt', text: 'pricing' },
          { type: 'response', text: 'These are entry points. Final pricing depends on scope, deadline, feature count and integration level.' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">Website</div><div class="stat-value">from PLN 1000</div><div class="card-copy">for simpler websites and landing pages. More advanced builds are quoted individually.</div></div>
              <div class="card"><div class="card-title">IT Support</div><div class="stat-value">from PLN 300 / month</div><div class="card-copy">for small businesses that want stable support and a shorter path to solving technical problems.</div></div>
            </div>` }
        ]
      },
      {
        id: 'projects',
        state: 'projects',
        lines: [
          { type: 'prompt', text: 'projects' },
          { type: 'response', text: 'Selected projects. Type a project name as a command to open a short case study.' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">strzelca.pl</div><div class="card-copy">store, blog and marketplace for the shooting community</div></div>
              <div class="card"><div class="card-title">get-dog.com</div><div class="card-copy">light and polished promo website for a macOS product</div></div>
              <div class="card"><div class="card-title">sredzka-korona.pl</div><div class="card-copy">hotel and restaurant website with a custom booking system</div></div>
              <div class="card"><div class="card-title">Tip</div><div class="card-copy">Type: <span class="emphasis">strzelca.pl</span>, <span class="emphasis">get-dog.com</span> or <span class="emphasis">sredzka-korona.pl</span></div></div>
            </div>` }
        ]
      },
      {
        id: 'workflow',
        state: 'workflow',
        lines: [
          { type: 'prompt', text: 'workflow' },
          { type: 'html', html: `
            <div class="cards fade-in">
              <div class="card"><div class="card-title">01. Discovery</div><div class="card-copy">We define the goal, priorities and scope. No needless complication.</div></div>
              <div class="card"><div class="card-title">02. Design</div><div class="card-copy">I shape the structure, visual language and logic around your actual workflow or sales model.</div></div>
              <div class="card"><div class="card-title">03. Delivery</div><div class="card-copy">I build the solution, handle the technical details and make sure it runs smoothly.</div></div>
              <div class="card"><div class="card-title">04. Support</div><div class="card-copy">After launch I can stay on the technical side and keep things in order.</div></div>
            </div>` }
        ]
      },
      {
        id: 'contact',
        state: 'contact',
        lines: [
          { type: 'prompt', text: 'contact' },
          { type: 'response', text: 'You can call, send an email or move straight to the form and describe your project.' },
          { type: 'html', html: `
            <div class="contact-grid fade-in">
              <a class="card" href="tel:+48575757817"><div class="card-title">Phone</div><div class="card-copy">57 57 57 817</div></a>
              <a class="card" href="mailto:igor.janicki27@gmail.com"><div class="card-title">E-mail</div><div class="card-copy">igor.janicki27@gmail.com</div></a>
              <div class="card"><div class="card-title">Work model</div><div class="card-copy">Mostly remote. Direct, efficient and without unnecessary ceremony.</div></div>
            </div>` }
        ]
      },
      {
        id: 'form',
        state: 'form',
        lines: [
          { type: 'prompt', text: 'form' },
          { type: 'response', text: 'Fill out the form below. The more clearly you describe the topic, the faster I can return with a sensible answer.' }
        ],
        showForm: true
      }
    ],
    projectDetails: {
      'strzelca.pl': {
        title: 'strzelca.pl',
        kicker: 'private project',
        quote: 'A broader ecosystem combining content, commerce and community features for a military and shooting-related audience.',
        bullets: [
          'A project focused on military and shooting-related topics.',
          'Target audience: sport shooters, collectors and people connected with the niche.',
          'Scope: full store, blog, marketplace, micro-payments and user accounts.',
          'A project where the visual layer had to match real functionality and product growth.'
        ],
        metrics: ['Store + blog + marketplace', 'Micro-payments and accounts', 'Custom product development']
      },
      'get-dog.com': {
        title: 'get-dog.com',
        kicker: 'promo website for an app',
        quote: 'A light, clean and visually polished website promoting an application for macOS users.',
        bullets: [
          'Built for Apple and macOS users.',
          'Goal: a simple, affordable and attractive landing page that presents the product well.',
          'Scope: promo site and downloadable resources.',
          'The key was clarity, low friction and a pleasant user experience.'
        ],
        metrics: ['macOS audience', 'lightweight architecture', 'clear communication']
      },
      'sredzka-korona.pl': {
        title: 'sredzka-korona.pl',
        kicker: 'hotel / restaurant / events',
        quote: 'A business website connected with a custom booking system and admin panel.',
        bullets: [
          'A project for a hotel, restaurant and events business.',
          'The scope went beyond presentation alone.',
          'I built a custom reservation system and an admin panel powering the site.',
          'A good example of front-end presence working together with operational backend tools.'
        ],
        metrics: ['Custom booking system', 'Admin panel', 'Website + operational backend']
      }
    }
  }
};

function t(key) { return translations[currentLang][key]; }
function steps() { return translations[currentLang].steps; }

function saveSession() {
  localStorage.setItem(SESSION_KEY, JSON.stringify({
    ts: Date.now(),
    currentStep,
    currentLang,
    currentTheme
  }));
}

function getSession() {
  const raw = localStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (Date.now() - parsed.ts > SESSION_TTL) {
      localStorage.removeItem(SESSION_KEY);
      return null;
    }
    return parsed;
  } catch {
    localStorage.removeItem(SESSION_KEY);
    return null;
  }
}

function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}

function setTerminalState(text) {
  els.terminalState.textContent = text;
}

function applyStaticTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    if (t(key) !== undefined) el.textContent = t(key);
  });
  els.body.dataset.lang = currentLang;
  els.body.dataset.theme = currentTheme;
  els.floatingContact.setAttribute('aria-label', currentLang === 'pl' ? 'Przejdź do kontaktu' : 'Go to contact');
  buildLegend();
  buildQuickPills();
  populateFormSelects();
}

function buildLegend() {
  const commands = t('commands').map(item => `<code>${item}</code>`).join(' ');
  els.legend.innerHTML = `${t('legendLabel')} ${commands}`;
}

function buildQuickPills() {
  els.quickPills.innerHTML = '';
  t('commandPills').forEach(item => {
    const btn = document.createElement('button');
    btn.className = 'side-pill';
    btn.type = 'button';
    btn.textContent = item;
    btn.addEventListener('click', () => handleCommand(item));
    els.quickPills.appendChild(btn);
  });
}

function populateFormSelects() {
  els.serviceSelect.innerHTML = '';
  t('services').forEach(service => {
    const option = document.createElement('option');
    option.value = service;
    option.textContent = service;
    els.serviceSelect.appendChild(option);
  });

  els.timelineSelect.innerHTML = '';
  t('timelines').forEach(time => {
    const option = document.createElement('option');
    option.value = time;
    option.textContent = time;
    els.timelineSelect.appendChild(option);
  });

  updateDynamicQuestion();
}

function updateDynamicQuestion() {
  const selected = els.serviceSelect.value;
  els.dynamicQuestionLabel.textContent = t('dynamicQuestions')[selected] || '';
  els.dynamicAnswer.placeholder = currentLang === 'pl' ? 'Wpisz odpowiedź…' : 'Type your answer…';
}

function appendLine(line) {
  const wrap = document.createElement('div');
  wrap.className = 'block fade-in';
  if (line.type === 'prompt') {
    wrap.innerHTML = `<span class="prompt">&gt; ${line.text}</span>`;
  } else if (line.type === 'response') {
    wrap.innerHTML = `<div class="response">${line.text}</div>`;
  } else if (line.type === 'html') {
    wrap.innerHTML = line.html;
  }
  els.output.appendChild(wrap);
  scrollTerminalToBottom();
}

function scrollTerminalToBottom() {
  const terminalBody = document.getElementById('terminal-body');
  terminalBody.scrollTop = terminalBody.scrollHeight;
}

function typeText(text, className = 'response') {
  return new Promise(resolve => {
    const block = document.createElement('div');
    block.className = `block ${className === 'prompt' ? 'prompt' : 'response'} fade-in`;
    const span = document.createElement('span');
    const caret = document.createElement('span');
    caret.className = 'caret';
    block.appendChild(span);
    block.appendChild(caret);
    els.output.appendChild(block);
    isTyping = true;
    let i = 0;

    const tick = () => {
      span.textContent = (className === 'prompt' ? '> ' : '') + text.slice(0, i);
      scrollTerminalToBottom();
      if (i < text.length) {
        i += 1;
        setTimeout(tick, 11);
      } else {
        caret.remove();
        isTyping = false;
        resolve();
      }
    };

    tick();
  });
}

async function renderStep(stepIndex, { replace = false } = {}) {
  if (stepIndex < 0 || stepIndex >= steps().length) return;
  currentStep = stepIndex;
  saveSession();
  if (replace) els.output.innerHTML = '';
  els.contactForm.classList.add('hidden');
  els.commandPanel.classList.remove('hidden');

  const step = steps()[stepIndex];
  setTerminalState(step.state || 'ready');

  for (const line of step.lines) {
    if (line.type === 'prompt') await typeText(line.text, 'prompt');
    else if (line.type === 'response') await typeText(line.text, 'response');
    else {
      appendLine(line);
      await pause(80);
    }
  }

  if (step.showForm) {
    els.contactForm.classList.remove('hidden');
    els.commandPanel.classList.add('hidden');
    setTimeout(() => els.contactForm.querySelector('input,select,textarea')?.focus(), 120);
  }

  els.progress.textContent = `${String(stepIndex + 1).padStart(2, '0')} / ${String(steps().length).padStart(2, '0')}`;
  saveSession();
}

function pause(ms) { return new Promise(r => setTimeout(r, ms)); }

function goNext() {
  if (isTyping) return appendLine({ type: 'response', text: t('typingWait') });
  if (currentStep < steps().length - 1) renderStep(currentStep + 1, { replace: true });
}

function goPrev() {
  if (isTyping) return appendLine({ type: 'response', text: t('typingWait') });
  if (currentStep > 0) renderStep(currentStep - 1, { replace: true });
}

function renderProjectDetail(key) {
  const data = translations[currentLang].projectDetails[key];
  if (!data) return false;
  appendLine({ type: 'prompt', text: key });
  appendLine({
    type: 'html',
    html: `
      <div class="project-story fade-in">
        <div class="card story-main">
          <div class="section-kicker">${data.kicker}</div>
          <div class="card-title">${data.title}</div>
          <div class="quote">${data.quote}</div>
          <div class="card-copy" style="margin-top:16px;">${data.bullets.map(item => `<div>• ${item}</div>`).join('')}</div>
        </div>
        <div class="card story-side">
          <div class="card-title">${currentLang === 'pl' ? 'Najważniejsze elementy' : 'Highlights'}</div>
          ${data.metrics.map(metric => `<div class="project-metric"><strong>${metric}</strong></div>`).join('')}
        </div>
      </div>`
  });
  return true;
}

function normalizeCommand(raw) {
  return raw.trim().toLowerCase();
}

function handleCommand(raw) {
  const cmd = normalizeCommand(raw);
  if (!cmd) return;
  if (isTyping) {
    appendLine({ type: 'response', text: t('typingWait') });
    return;
  }
  appendLine({ type: 'prompt', text: raw });
  els.commandInput.value = '';

  const maps = {
    pl: {
      'pomoc': () => appendLine({ type: 'response', text: t('commands').join(' • ') }),
      'dalej': goNext,
      'wstecz': goPrev,
      'o mnie': () => renderStep(1, { replace: true }),
      'usługi': () => renderStep(2, { replace: true }),
      'uslugi': () => renderStep(2, { replace: true }),
      'cennik': () => renderStep(3, { replace: true }),
      'projekty': () => renderStep(4, { replace: true }),
      'jak pracuję': () => renderStep(5, { replace: true }),
      'jak pracuje': () => renderStep(5, { replace: true }),
      'kontakt': () => renderStep(6, { replace: true }),
      'formularz': () => renderStep(7, { replace: true }),
      'jasny': () => setTheme('light'),
      'ciemny': () => setTheme('dark'),
      'polski': () => setLanguage('pl'),
      'english': () => setLanguage('en'),
      'strzelca.pl': () => renderProjectDetail('strzelca.pl'),
      'get-dog.com': () => renderProjectDetail('get-dog.com'),
      'sredzka-korona.pl': () => renderProjectDetail('sredzka-korona.pl')
    },
    en: {
      'help': () => appendLine({ type: 'response', text: t('commands').join(' • ') }),
      'next': goNext,
      'back': goPrev,
      'about': () => renderStep(1, { replace: true }),
      'services': () => renderStep(2, { replace: true }),
      'pricing': () => renderStep(3, { replace: true }),
      'projects': () => renderStep(4, { replace: true }),
      'workflow': () => renderStep(5, { replace: true }),
      'contact': () => renderStep(6, { replace: true }),
      'form': () => renderStep(7, { replace: true }),
      'light': () => setTheme('light'),
      'dark': () => setTheme('dark'),
      'polish': () => setLanguage('pl'),
      'english': () => setLanguage('en'),
      'strzelca.pl': () => renderProjectDetail('strzelca.pl'),
      'get-dog.com': () => renderProjectDetail('get-dog.com'),
      'sredzka-korona.pl': () => renderProjectDetail('sredzka-korona.pl')
    }
  };

  const active = maps[currentLang][cmd];
  if (active) active();
  else appendLine({ type: 'response', text: t('commandNotFound') });
}

async function submitForm(e) {
  e.preventDefault();
  const honey = els.contactForm.querySelector('[name="_honey"]').value;
  if (honey) return;
  if (Date.now() - formStartedAt < 4000) {
    appendLine({ type: 'response', text: currentLang === 'pl' ? 'Poczekaj chwilę przed wysłaniem formularza.' : 'Please wait a few seconds before sending the form.' });
    return;
  }

  const sendBtn = document.getElementById('send-btn');
  sendBtn.disabled = true;
  sendBtn.textContent = currentLang === 'pl' ? 'Wysyłanie…' : 'Sending…';

  try {
    const formData = new FormData(els.contactForm);
    formData.set('_subject', currentLang === 'pl' ? 'Nowe zapytanie z i-janicki.pl' : 'New inquiry from i-janicki.pl');

    const response = await fetch('https://formsubmit.co/ajax/igor.janicki27@gmail.com', {
      method: 'POST',
      body: formData,
      headers: { Accept: 'application/json' }
    });
    const data = await response.json();

    if (data.success === true || data.success === 'true') {
      appendLine({ type: 'response', text: t('formSuccess') });
      els.contactForm.reset();
      populateFormSelects();
      formStartedAt = Date.now();
    } else {
      appendLine({ type: 'response', text: t('formError') });
    }
  } catch {
    appendLine({ type: 'response', text: t('formError') });
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = t('sendBtn');
  }
}

function setLanguage(lang) {
  if (!translations[lang]) return;
  currentLang = lang;
  applyStaticTranslations();
  renderStep(currentStep, { replace: true });
  saveSession();
}

function setTheme(theme) {
  currentTheme = theme;
  els.body.dataset.theme = theme;
  saveSession();
}

async function boot() {
  els.bootLog.textContent = '';
  const lines = t('boot');
  for (let i = 0; i < lines.length; i++) {
    els.bootLog.textContent += `${lines[i]}\n`;
    els.bootFill.style.width = `${((i + 1) / lines.length) * 100}%`;
    await pause(280);
  }
  await pause(180);
  els.bootScreen.classList.add('hidden');

  const saved = getSession();
  if (saved) {
    currentLang = saved.currentLang || currentLang;
    currentTheme = saved.currentTheme || currentTheme;
    els.body.dataset.lang = currentLang;
    els.body.dataset.theme = currentTheme;
    applyStaticTranslations();
    els.resumeModal.classList.remove('hidden');
    document.getElementById('resume-continue').onclick = () => {
      els.resumeModal.classList.add('hidden');
      renderStep(saved.currentStep || 0, { replace: true });
    };
    document.getElementById('resume-reset').onclick = () => {
      clearSession();
      els.resumeModal.classList.add('hidden');
      renderStep(0, { replace: true });
    };
  } else {
    renderStep(0, { replace: true });
  }
}

els.nextBtn.addEventListener('click', goNext);
els.prevBtn.addEventListener('click', goPrev);
els.commandInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') handleCommand(els.commandInput.value);
});
els.serviceSelect.addEventListener('change', updateDynamicQuestion);
els.contactForm.addEventListener('submit', submitForm);
els.langToggle.addEventListener('click', () => setLanguage(currentLang === 'pl' ? 'en' : 'pl'));
els.themeToggle.addEventListener('click', () => setTheme(currentTheme === 'dark' ? 'light' : 'dark'));
els.floatingContact.addEventListener('click', () => renderStep(7, { replace: true }));

document.addEventListener('keydown', e => {
  const activeTag = document.activeElement?.tagName;
  if (['INPUT', 'TEXTAREA', 'SELECT'].includes(activeTag)) return;
  if (e.key === 'ArrowRight' || e.key === 'PageDown') goNext();
  if (e.key === 'ArrowLeft' || e.key === 'PageUp') goPrev();
  if (e.key === ' ' || e.key === 'Enter') {
    e.preventDefault();
    goNext();
  }
});

document.addEventListener('wheel', e => {
  if (wheelLock) return;
  wheelLock = true;
  setTimeout(() => wheelLock = false, 650);
  if (e.deltaY > 14) goNext();
  if (e.deltaY < -14) goPrev();
}, { passive: true });

applyStaticTranslations();
boot();
