i-JANICKI — gotowa strona one-page w stylu terminala

Zawartość:
- index.html
- styles.css
- script.js

Jak uruchomić:
1. Wrzuć pliki na hosting statyczny.
2. Otwórz index.html lokalnie lub przez serwer.

Formularz kontaktowy:
- Formularz wysyła wiadomości przez FormSubmit na adres: igor.janicki27@gmail.com
- Przy pierwszym wysłaniu FormSubmit wyśle mail aktywacyjny na tę skrzynkę.
- Trzeba kliknąć link aktywacyjny w mailu, żeby formularz zaczął działać produkcyjnie.

Co możesz łatwo zmienić:
- Teksty: script.js -> translations
- Projekty i opisy: index.html + script.js
- Kolory / wygląd: styles.css
- Adres odbiorczy formularza: script.js (fetch do formsubmit)

Uwagi:
- Strona jest dwujęzyczna: PL / EN
- Na desktopie działa nawigacja przez przycisk, klawisze i scroll.
- Na mobile najlepiej używać przycisków oraz przycisku floating "Kontakt".
