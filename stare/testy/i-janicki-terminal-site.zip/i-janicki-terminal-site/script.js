const translations = {
  pl: {
    pageTitle: 'i-JANICKI — Strony, aplikacje i opieka IT',
    pageDescription: 'i-JANICKI tworzy strony internetowe, aplikacje oraz wspiera małe biznesy w codziennej opiece informatycznej.',
    skip: 'Przejdź do kontaktu',
    statusLabel: 'Terminal sesji',
    statusText: 'Projektowanie stron, aplikacji i wsparcie IT dla małych biznesów.',
    navIntro: 'Start',
    navAbout: 'O mnie',
    navServices: 'Usługi',
    navProjects: 'Projekty',
    navContact: 'Kontakt',
    statusFooter: 'Dostępny do współpracy zdalnej',
    metaLabel: 'interactive session',
    back: 'Wstecz',
    next: 'Dalej',
    floatingContact: 'Kontakt',
    introCommand: './start-session',
    introHeadline: 'Witaj. Nazywam się Igor Janicki.',
    introBody1: 'Tworzę strony HTML/CSS, aplikacje Python i Swift oraz wspieram małe biznesy w codziennej opiece informatycznej.',
    introBody2: 'Ta strona działa jak elegancki terminal — prowadzi Cię przez ofertę, projekty i kontakt bez zbędnego chaosu.',
    networkLabel: 'Sieci i opieka IT',
    aboutCommand: 'cat about.txt',
    aboutTitle: '[ O mnie ]',
    aboutBody1: 'Buduję rozwiązania, które mają wyglądać profesjonalnie, działać szybko i nie sprawiać problemów po wdrożeniu.',
    aboutBody2: 'Łączę estetykę premium z praktycznym podejściem. Strona, aplikacja albo bieżąca opieka IT mają po prostu wspierać biznes.',
    aboutBody3: 'Pracuję głównie zdalnie i stawiam na prostą komunikację, rozsądne rozwiązania oraz jakość, którą widać od pierwszego kontaktu.',
    metricRemote: 'Model współpracy',
    metricContact: 'Bezpośredni kontakt',
    metricQuality: 'Standard wykonania',
    servicesCommand: 'ls services/',
    servicesTitle: '[ Usługi ]',
    service1Title: 'Strony internetowe',
    service1Body: 'Nowoczesne strony dla małych biznesów: lekkie, estetyczne i dopracowane wizualnie.',
    service2Title: 'Aplikacje Python',
    service2Body: 'Narzędzia desktopowe, automatyzacje i rozwiązania skrojone pod konkretny proces.',
    service3Title: 'Aplikacje Swift',
    service3Body: 'Dedykowane aplikacje i prototypy pod środowisko Apple.',
    service4Title: 'Administracja sieci',
    service4Body: 'Wsparcie w konfiguracji, porządkowaniu i utrzymaniu środowiska sieciowego.',
    service5Title: 'Opieka informatyczna',
    service5Body: 'Stałe lub okazjonalne wsparcie IT dla małych firm, które chcą działać spokojniej.',
    projectsCommand: 'open portfolio.json',
    projectsTitle: '[ Projekty ]',
    project1Body: 'Rozbudowany projekt internetowy z naciskiem na strukturę, branding i rozwój większego ekosystemu.',
    project2Body: 'Projekt internetowy nastawiony na czytelny przekaz, użyteczność i nowoczesny odbiór wizualny.',
    project3Body: 'Realizacja strony internetowej z myślą o profesjonalnej prezentacji oferty i wygodnym kontakcie.',
    contactCommand: './contact --init',
    contactTitle: '[ Kontakt ]',
    contactLead: 'Opisz krótko, czego potrzebujesz. Odpowiem możliwie konkretnie i bez zbędnego przeciągania.',
    fieldName: 'imię',
    fieldEmail: 'e-mail',
    fieldBudget: 'budżet',
    fieldMessage: 'opis projektu',
    sendButton: 'Wyślij zapytanie',
    responseSending: '> Trwa wysyłanie wiadomości...',
    responseSuccess: '> Wiadomość została wysłana pomyślnie. Odpowiem tak szybko, jak to możliwe.',
    responseError: '> Nie udało się wysłać wiadomości. Spróbuj ponownie lub napisz bezpośrednio na e-mail.',
    responseValidation: '> Uzupełnij wymagane pola formularza.',
  },
  en: {
    pageTitle: 'i-JANICKI — Websites, apps and IT support',
    pageDescription: 'i-JANICKI builds websites, apps and supports small businesses with practical IT care.',
    skip: 'Jump to contact',
    statusLabel: 'Session terminal',
    statusText: 'Web design, app development and IT support for small businesses.',
    navIntro: 'Start',
    navAbout: 'About',
    navServices: 'Services',
    navProjects: 'Projects',
    navContact: 'Contact',
    statusFooter: 'Available for remote collaboration',
    metaLabel: 'interactive session',
    back: 'Back',
    next: 'Next',
    floatingContact: 'Contact',
    introCommand: './start-session',
    introHeadline: 'Hello. My name is Igor Janicki.',
    introBody1: 'I build HTML/CSS websites, Python and Swift apps, and provide day-to-day IT support for small businesses.',
    introBody2: 'This website works like an elegant terminal — guiding visitors through the offer, projects and contact without unnecessary clutter.',
    networkLabel: 'Networks & IT care',
    aboutCommand: 'cat about.txt',
    aboutTitle: '[ About ]',
    aboutBody1: 'I build solutions that should look professional, work fast and stay reliable after launch.',
    aboutBody2: 'I combine premium aesthetics with a practical mindset. A website, an app or ongoing IT support should simply help the business move forward.',
    aboutBody3: 'I work mainly remotely and focus on direct communication, sensible solutions and quality that is visible from the first interaction.',
    metricRemote: 'Work model',
    metricContact: 'Direct contact',
    metricQuality: 'Delivery standard',
    servicesCommand: 'ls services/',
    servicesTitle: '[ Services ]',
    service1Title: 'Websites',
    service1Body: 'Modern websites for small businesses: lightweight, polished and visually refined.',
    service2Title: 'Python apps',
    service2Body: 'Desktop tools, automations and custom solutions tailored to real processes.',
    service3Title: 'Swift apps',
    service3Body: 'Dedicated apps and prototypes for the Apple ecosystem.',
    service4Title: 'Network administration',
    service4Body: 'Support in configuring, organizing and maintaining network environments.',
    service5Title: 'IT support',
    service5Body: 'Ongoing or occasional IT support for small companies that want less friction and more calm.',
    projectsCommand: 'open portfolio.json',
    projectsTitle: '[ Projects ]',
    project1Body: 'A broad web project focused on structure, branding and long-term ecosystem growth.',
    project2Body: 'A website focused on clear communication, usability and a modern visual feel.',
    project3Body: 'A website created for professional presentation, clarity and easy contact.',
    contactCommand: './contact --init',
    contactTitle: '[ Contact ]',
    contactLead: 'Describe what you need in a few lines. I will reply clearly and without unnecessary delay.',
    fieldName: 'name',
    fieldEmail: 'e-mail',
    fieldBudget: 'budget',
    fieldMessage: 'project brief',
    sendButton: 'Send inquiry',
    responseSending: '> Sending message...',
    responseSuccess: '> Your message has been sent successfully. I will reply as soon as possible.',
    responseError: '> Message could not be sent. Please try again or use direct e-mail.',
    responseValidation: '> Please fill in the required form fields.',
  }
};

const stepTemplates = [
  'template-intro',
  'template-about',
  'template-services',
  'template-projects',
  'template-contact',
];

const terminalOutput = document.getElementById('terminalOutput');
const nextButton = document.getElementById('nextButton');
const backButton = document.getElementById('backButton');
const skipButton = document.getElementById('skipButton');
const floatingContact = document.getElementById('floatingContact');
const progressButtons = [...document.querySelectorAll('.progress-nav__item')];
const langButtons = [...document.querySelectorAll('.language-switch__button')];

let currentLang = 'pl';
let currentStep = 0;
let renderedSteps = new Set();
let isAnimating = false;

function translateStaticContent() {
  document.documentElement.lang = currentLang;
  document.title = translations[currentLang].pageTitle;
  document.querySelector('meta[name="description"]').setAttribute('content', translations[currentLang].pageDescription);

  document.querySelectorAll('[data-i18n]').forEach((node) => {
    const key = node.dataset.i18n;
    if (translations[currentLang][key]) {
      node.textContent = translations[currentLang][key];
    }
  });

  langButtons.forEach((btn) => {
    btn.classList.toggle('is-active', btn.dataset.lang === currentLang);
  });
}

function createStep(stepIndex) {
  const template = document.getElementById(stepTemplates[stepIndex]);
  return template.content.firstElementChild.cloneNode(true);
}

function applyTranslationsToStep(stepElement) {
  stepElement.querySelectorAll('[data-i18n]').forEach((node) => {
    const key = node.dataset.i18n;
    if (translations[currentLang][key]) {
      node.textContent = translations[currentLang][key];
    }
  });

  const budgetInput = stepElement.querySelector('input[name="budget"]');
  if (budgetInput) {
    budgetInput.placeholder = currentLang === 'pl' ? 'np. 3000–5000 PLN' : 'e.g. 3000–5000 PLN';
  }
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function typeLine(line) {
  const original = line.textContent;
  line.textContent = '';
  line.classList.add('is-visible', 'typing-cursor');

  for (let i = 0; i < original.length; i += 1) {
    line.textContent += original[i];
    if (!document.hidden) {
      await wait(Math.min(18 + Math.random() * 8, 26));
    }
  }

  line.classList.remove('typing-cursor');
}

async function animateStep(stepElement) {
  const typedLines = [...stepElement.querySelectorAll('[data-type]')];
  const revealBlocks = [...stepElement.querySelectorAll('.terminal-tag-row, .terminal-metrics, .service-grid, .project-list, .terminal-form, .contact-inline')];

  for (const line of typedLines) {
    await typeLine(line);
    terminalOutput.scrollTop = terminalOutput.scrollHeight;
    await wait(40);
  }

  revealBlocks.forEach((block, index) => {
    setTimeout(() => block.classList.add('is-visible'), 60 * index);
  });

  await wait(180);
  terminalOutput.scrollTop = terminalOutput.scrollHeight;
}

async function ensureStep(stepIndex) {
  if (renderedSteps.has(stepIndex)) {
    return;
  }

  const stepElement = createStep(stepIndex);
  applyTranslationsToStep(stepElement);
  terminalOutput.appendChild(stepElement);
  renderedSteps.add(stepIndex);

  if (stepIndex === 4) {
    attachFormHandler(stepElement.querySelector('#contactForm'));
  }

  isAnimating = true;
  updateButtons();
  await animateStep(stepElement);
  isAnimating = false;
  updateButtons();
}

async function goToStep(stepIndex) {
  if (stepIndex < 0 || stepIndex > stepTemplates.length - 1 || isAnimating) {
    return;
  }

  currentStep = stepIndex;
  updateProgress();

  for (let i = 0; i <= stepIndex; i += 1) {
    await ensureStep(i);
  }

  const target = terminalOutput.querySelector(`[data-step="${stepIndex}"]`);
  if (target) {
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

function updateProgress() {
  progressButtons.forEach((button) => {
    button.classList.toggle('is-active', Number(button.dataset.stepTarget) === currentStep);
  });
}

function updateButtons() {
  backButton.disabled = currentStep === 0 || isAnimating;
  nextButton.disabled = currentStep === stepTemplates.length - 1 || isAnimating;
  backButton.style.opacity = backButton.disabled ? '0.45' : '1';
  nextButton.style.opacity = nextButton.disabled ? '0.45' : '1';
}

function replaceRenderedContent() {
  terminalOutput.innerHTML = '';
  renderedSteps = new Set();
}

async function rerenderAll() {
  const targetStep = currentStep;
  replaceRenderedContent();
  updateProgress();
  updateButtons();

  for (let i = 0; i <= targetStep; i += 1) {
    const stepElement = createStep(i);
    applyTranslationsToStep(stepElement);

    stepElement.querySelectorAll('[data-type]').forEach((line) => {
      line.classList.add('is-visible');
    });
    stepElement.querySelectorAll('.terminal-tag-row, .terminal-metrics, .service-grid, .project-list, .terminal-form, .contact-inline').forEach((block) => {
      block.classList.add('is-visible');
    });

    terminalOutput.appendChild(stepElement);
    renderedSteps.add(i);

    if (i === 4) {
      attachFormHandler(stepElement.querySelector('#contactForm'));
    }
  }

  const target = terminalOutput.querySelector(`[data-step="${targetStep}"]`);
  if (target) {
    target.scrollIntoView({ behavior: 'auto', block: 'start' });
  }
}

function attachFormHandler(form) {
  if (!form || form.dataset.bound === 'true') {
    return;
  }

  form.dataset.bound = 'true';
  const response = form.querySelector('#formResponse');
  const submitButton = form.querySelector('#submitButton');

  form.addEventListener('submit', async (event) => {
    event.preventDefault();

    if (!form.reportValidity()) {
      response.textContent = translations[currentLang].responseValidation;
      response.className = 'terminal-response is-error';
      return;
    }

    response.textContent = translations[currentLang].responseSending;
    response.className = 'terminal-response';
    submitButton.disabled = true;
    submitButton.style.opacity = '0.6';

    try {
      const formData = new FormData(form);
      const payload = Object.fromEntries(formData.entries());

      const result = await fetch('https://formsubmit.co/ajax/igor.janicki27@gmail.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await result.json();

      if (!result.ok || data.success === 'false') {
        throw new Error('Form submission failed');
      }

      form.reset();
      response.textContent = translations[currentLang].responseSuccess;
      response.className = 'terminal-response is-success';
    } catch (error) {
      response.textContent = translations[currentLang].responseError;
      response.className = 'terminal-response is-error';
    } finally {
      submitButton.disabled = false;
      submitButton.style.opacity = '1';
    }
  });
}

function handleWheel(event) {
  if (window.innerWidth <= 1080 || isAnimating) {
    return;
  }

  const target = event.target;
  if (target.closest('.terminal-output')) {
    const atBottom = terminalOutput.scrollTop + terminalOutput.clientHeight >= terminalOutput.scrollHeight - 6;
    const atTop = terminalOutput.scrollTop <= 2;

    if (event.deltaY > 20 && atBottom && currentStep < stepTemplates.length - 1) {
      event.preventDefault();
      goToStep(currentStep + 1);
    } else if (event.deltaY < -20 && atTop && currentStep > 0) {
      event.preventDefault();
      goToStep(currentStep - 1);
    }
  }
}

nextButton.addEventListener('click', () => goToStep(currentStep + 1));
backButton.addEventListener('click', () => goToStep(currentStep - 1));
skipButton.addEventListener('click', () => goToStep(4));
floatingContact.addEventListener('click', () => goToStep(4));

progressButtons.forEach((button) => {
  button.addEventListener('click', () => {
    goToStep(Number(button.dataset.stepTarget));
  });
});

langButtons.forEach((button) => {
  button.addEventListener('click', async () => {
    const newLang = button.dataset.lang;
    if (newLang === currentLang || isAnimating) {
      return;
    }
    currentLang = newLang;
    translateStaticContent();
    await rerenderAll();
  });
});

document.addEventListener('keydown', (event) => {
  const tag = document.activeElement?.tagName;
  const typingInForm = tag === 'INPUT' || tag === 'TEXTAREA';
  if (typingInForm) return;

  if ((event.key === 'Enter' || event.key === ' ' || event.key === 'ArrowDown') && currentStep < stepTemplates.length - 1) {
    event.preventDefault();
    goToStep(currentStep + 1);
  }

  if (event.key === 'ArrowUp' && currentStep > 0) {
    event.preventDefault();
    goToStep(currentStep - 1);
  }
});

document.addEventListener('wheel', handleWheel, { passive: false });

translateStaticContent();
goToStep(0);
